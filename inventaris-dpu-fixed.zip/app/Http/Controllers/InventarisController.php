<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class InventarisController extends Controller
{
    // ============================================================
    // DATA DUMMY TERPUSAT
    // ============================================================
    private function getKantorData(): array
    {
        return [
            'pku' => [
                'nama' => 'Kantor Pusat Pekanbaru', 'short' => 'Pekanbaru',
                'opNama' => 'Rina Amelia',
                'stat' => ['total' => 342, 'nilai' => '1.1M', 'kritis' => 5, 'perbaikan' => 3, 'baik' => 334, 'rusak' => 5],
                'aset' => [
                    ['kode'=>'DPU-2201','nama'=>'MacBook Pro 14" M3 Pro','kategori'=>'Elektronik & IT','ruangan'=>'Lt. 3 - Dept. IT','kondisi'=>'Baik','nilai'=>'42.500.000','tanggal'=>'12 Mar 2024','sn'=>'C50LL928X-PRO','pj'=>'Andri Wijaya','catatan'=>'Unit baru, kondisi prima.','kantor'=>'Pekanbaru'],
                    ['kode'=>'DPU-2202','nama'=>'AC Split 2PK Daikin','kategori'=>'Mekanikal & Elektrikal','ruangan'=>'Ruang Rapat Lt.3','kondisi'=>'Dalam Perbaikan','nilai'=>'8.500.000','tanggal'=>'5 Jan 2023','sn'=>'DKAC-220X','pj'=>'Hadi Prasetyo','catatan'=>'Kompresor bermasalah, sudah dibawa ke teknisi.','kantor'=>'Pekanbaru'],
                    ['kode'=>'DPU-2203','nama'=>'Genset 500kVA Perkins','kategori'=>'Infrastruktur','ruangan'=>'Basement','kondisi'=>'Rusak','nilai'=>'185.000.000','tanggal'=>'20 Jul 2021','sn'=>'PRKS-500-2021','pj'=>'Hadi Prasetyo','catatan'=>'Kerusakan pada alternator, perlu penggantian part.','kantor'=>'Pekanbaru'],
                    ['kode'=>'DPU-2204','nama'=>'Proyektor Epson EB-X49','kategori'=>'Elektronik & IT','ruangan'=>'Ruang Pelatihan','kondisi'=>'Baik','nilai'=>'5.200.000','tanggal'=>'3 Sep 2023','sn'=>'EBX49-2023','pj'=>'Sari Dewi','catatan'=>'','kantor'=>'Pekanbaru'],
                    ['kode'=>'DPU-2205','nama'=>'Meja Kerja Standing Desk','kategori'=>'Furnitur Kantor','ruangan'=>'Lt. 2 - Open Space','kondisi'=>'Baik','nilai'=>'3.800.000','tanggal'=>'15 Feb 2024','sn'=>'-','pj'=>'Sari Dewi','catatan'=>'','kantor'=>'Pekanbaru'],
                ],
                'stok' => [
                    ['kode'=>'STK-001','nama'=>'Toner Printer HP LaserJet','satuan'=>'unit','stok'=>2,'min'=>5,'kategori'=>'Konsumabel','kantor'=>'Pekanbaru'],
                    ['kode'=>'STK-002','nama'=>'Kertas A4 80gsm','satuan'=>'rim','stok'=>15,'min'=>10,'kategori'=>'Konsumabel','kantor'=>'Pekanbaru'],
                    ['kode'=>'STK-003','nama'=>'Baterai UPS APC','satuan'=>'unit','stok'=>4,'min'=>3,'kategori'=>'Suku Cadang','kantor'=>'Pekanbaru'],
                    ['kode'=>'STK-004','nama'=>'Lampu LED 18W','satuan'=>'unit','stok'=>20,'min'=>10,'kategori'=>'Mekanikal','kantor'=>'Pekanbaru'],
                ],
            ],
            'jkt' => [
                'nama' => 'Kantor Proyek Tebet Jakarta', 'short' => 'Tebet Jakarta',
                'opNama' => 'Arif Budiman',
                'stat' => ['total' => 289, 'nilai' => '890jt', 'kritis' => 2, 'perbaikan' => 1, 'baik' => 288, 'rusak' => 1],
                'aset' => [
                    ['kode'=>'DPU-3101','nama'=>'Workstation Dell Precision 3660','kategori'=>'Elektronik & IT','ruangan'=>'Studio Desain','kondisi'=>'Baik','nilai'=>'28.000.000','tanggal'=>'1 Nov 2023','sn'=>'DELL-3660-2023','pj'=>'Budi Santoso','catatan'=>'','kantor'=>'Tebet Jakarta'],
                    ['kode'=>'DPU-3102','nama'=>'Plotter HP DesignJet T830','kategori'=>'Peralatan Arsitektur','ruangan'=>'Studio Desain','kondisi'=>'Baik','nilai'=>'22.500.000','tanggal'=>'1 Nov 2023','sn'=>'HPT830-001','pj'=>'Budi Santoso','catatan'=>'','kantor'=>'Tebet Jakarta'],
                    ['kode'=>'DPU-3103','nama'=>'UPS APC 3000VA','kategori'=>'Infrastruktur','ruangan'=>'Ruang Server','kondisi'=>'Dalam Perbaikan','nilai'=>'6.800.000','tanggal'=>'10 Mar 2022','sn'=>'APC3000-01','pj'=>'Arif Budiman','catatan'=>'Baterai aus, sedang pemesanan unit baru.','kantor'=>'Tebet Jakarta'],
                    ['kode'=>'DPU-3104','nama'=>'Kursi Ergonomis Herman Miller','kategori'=>'Furnitur Kantor','ruangan'=>'General','kondisi'=>'Baik','nilai'=>'12.500.000','tanggal'=>'5 Jan 2023','sn'=>'-','pj'=>'Arif Budiman','catatan'=>'','kantor'=>'Tebet Jakarta'],
                ],
                'stok' => [
                    ['kode'=>'STK-101','nama'=>'Cartridge Plotter HP','satuan'=>'unit','stok'=>3,'min'=>2,'kategori'=>'Konsumabel','kantor'=>'Tebet Jakarta'],
                    ['kode'=>'STK-102','nama'=>'Kertas Plotter A0','satuan'=>'roll','stok'=>5,'min'=>3,'kategori'=>'Konsumabel','kantor'=>'Tebet Jakarta'],
                ],
            ],
            'sby' => [
                'nama' => 'Kantor Proyek Surabaya', 'short' => 'Surabaya',
                'opNama' => 'Dewi Lestari',
                'stat' => ['total' => 187, 'nilai' => '620jt', 'kritis' => 1, 'perbaikan' => 2, 'baik' => 184, 'rusak' => 3],
                'aset' => [
                    ['kode'=>'DPU-4101','nama'=>'Laptop Asus Vivobook 15','kategori'=>'Elektronik & IT','ruangan'=>'Ruang Kerja','kondisi'=>'Baik','nilai'=>'9.500.000','tanggal'=>'20 Apr 2024','sn'=>'ASUS-VB15-2024','pj'=>'Dewi Lestari','catatan'=>'','kantor'=>'Surabaya'],
                    ['kode'=>'DPU-4102','nama'=>'Toyota Innova Crysta','kategori'=>'Kendaraan','ruangan'=>'Parkir','kondisi'=>'Baik','nilai'=>'320.000.000','tanggal'=>'10 Jun 2022','sn'=>'B-1234-XYZ','pj'=>'Firman Hadi','catatan'=>'','kantor'=>'Surabaya'],
                    ['kode'=>'DPU-4103','nama'=>'Total Station Topcon ES-103','kategori'=>'Peralatan Survey','ruangan'=>'Gudang Alat','kondisi'=>'Baik','nilai'=>'58.000.000','tanggal'=>'3 Aug 2023','sn'=>'TPC-ES103-23','pj'=>'Dewi Lestari','catatan'=>'','kantor'=>'Surabaya'],
                    ['kode'=>'DPU-4104','nama'=>'Laptop Dell Latitude 5540','kategori'=>'Elektronik & IT','ruangan'=>'Ruang Kerja','kondisi'=>'Rusak','nilai'=>'14.500.000','tanggal'=>'1 Sep 2023','sn'=>'DELL-L5540-01','pj'=>'Dewi Lestari','catatan'=>'LCD pecah, menunggu spare part.','kantor'=>'Surabaya'],
                ],
                'stok' => [
                    ['kode'=>'STK-201','nama'=>'Oli Mesin Toyota','satuan'=>'liter','stok'=>10,'min'=>5,'kategori'=>'Perawatan Kendaraan','kantor'=>'Surabaya'],
                    ['kode'=>'STK-202','nama'=>'Baterai Total Station','satuan'=>'unit','stok'=>0,'min'=>2,'kategori'=>'Suku Cadang','kantor'=>'Surabaya'],
                ],
            ],
            'bks' => [
                'nama' => 'Kantor Proyek Bekasi', 'short' => 'Bekasi',
                'opNama' => 'Hendra Susanto',
                'stat' => ['total' => 231, 'nilai' => '780jt', 'kritis' => 4, 'perbaikan' => 2, 'baik' => 226, 'rusak' => 5],
                'aset' => [
                    ['kode'=>'DPU-5101','nama'=>'Forklift Komatsu FG15','kategori'=>'Alat Berat','ruangan'=>'Gudang Bekasi','kondisi'=>'Baik','nilai'=>'148.000.000','tanggal'=>'12 Feb 2022','sn'=>'KMTSU-FG15-22','pj'=>'Hendra Susanto','catatan'=>'','kantor'=>'Bekasi'],
                    ['kode'=>'DPU-5102','nama'=>'Concrete Mixer Molen 500L','kategori'=>'Alat Berat','ruangan'=>'Area Proyek','kondisi'=>'Dalam Perbaikan','nilai'=>'35.000.000','tanggal'=>'5 May 2021','sn'=>'MOLEN-500-21','pj'=>'Hendra Susanto','catatan'=>'Gear box aus, sedang diperbaiki.','kantor'=>'Bekasi'],
                    ['kode'=>'DPU-5103','nama'=>'Scaffolding Set (50 unit)','kategori'=>'Peralatan Konstruksi','ruangan'=>'Gudang','kondisi'=>'Baik','nilai'=>'24.500.000','tanggal'=>'1 Jan 2020','sn'=>'-','pj'=>'Agus Kurniawan','catatan'=>'','kantor'=>'Bekasi'],
                    ['kode'=>'DPU-5104','nama'=>'Genset Mobile 100kVA','kategori'=>'Infrastruktur','ruangan'=>'Area Proyek','kondisi'=>'Rusak','nilai'=>'85.000.000','tanggal'=>'1 Jan 2021','sn'=>'GEN100K-21','pj'=>'Hendra Susanto','catatan'=>'Kerusakan pada panel kontrol.','kantor'=>'Bekasi'],
                ],
                'stok' => [
                    ['kode'=>'STK-301','nama'=>'Solar Industri','satuan'=>'liter','stok'=>200,'min'=>100,'kategori'=>'Bahan Bakar','kantor'=>'Bekasi'],
                    ['kode'=>'STK-302','nama'=>'Pelumas Alat Berat','satuan'=>'drum','stok'=>3,'min'=>2,'kategori'=>'Perawatan','kantor'=>'Bekasi'],
                    ['kode'=>'STK-303','nama'=>'Sabuk Pengaman','satuan'=>'unit','stok'=>8,'min'=>10,'kategori'=>'K3','kantor'=>'Bekasi'],
                ],
            ],
        ];
    }

    private function getActiveAset(): array
    {
        $kantorData = $this->getKantorData();
        if (Session::get('user_type') === 'admin') {
            $all = [];
            foreach ($kantorData as $data) {
                foreach ($data['aset'] as $a) {
                    $all[] = $a;
                }
            }
            return $all;
        }
        $kantorId = Session::get('kantor_id', 'pku');
        return $kantorData[$kantorId]['aset'] ?? [];
    }

    private function getActiveStat(): array
    {
        $kantorData = $this->getKantorData();
        if (Session::get('user_type') === 'admin') {
            $total = array_sum(array_column(array_column($kantorData, 'stat'), 'total'));
            $baik  = array_sum(array_column(array_column($kantorData, 'stat'), 'baik'));
            $perbaikan = array_sum(array_column(array_column($kantorData, 'stat'), 'perbaikan'));
            $rusak = array_sum(array_column(array_column($kantorData, 'stat'), 'rusak'));
            return ['total' => $total, 'nilai' => '3.4M', 'baik' => $baik, 'perbaikan' => $perbaikan, 'rusak' => $rusak];
        }
        $kantorId = Session::get('kantor_id', 'pku');
        return $kantorData[$kantorId]['stat'] ?? ['total'=>0,'nilai'=>'0','baik'=>0,'perbaikan'=>0,'rusak'=>0];
    }

    private function sharedViewData(): array
    {
        $kantorData = $this->getKantorData();
        return [
            'isAdmin'    => Session::get('user_type') === 'admin',
            'kantorList' => $kantorData,
            'asetList'   => $this->getActiveAset(),
        ];
    }

    // ============================================================
    // AUTH
    // ============================================================
    public function loginForm()
    {
        if (Session::has('user_name')) return redirect()->route('dashboard');
        return view('auth.login');
    }

    public function loginPost(Request $request)
    {
        $role     = $request->input('role', 'admin');
        $email    = $request->input('email');
        $password = $request->input('password');
        $kantorId = $request->input('kantor', 'pku');

        $kantorData = $this->getKantorData();

        if ($role === 'admin') {
            if ($email === 'admin@dianpilar.co.id' && $password === 'admin123') {
                Session::put('user_name', 'Ahmad Santoso');
                Session::put('user_email', $email);
                Session::put('user_role', 'Administrator');
                Session::put('user_type', 'admin');
                Session::put('kantor_id', 'all');
                return redirect()->route('dashboard');
            }
            return back()->withErrors(['Email atau kata sandi admin salah. Gunakan: admin@dianpilar.co.id / admin123']);
        }

        // Operator
        if ($email === 'operator@dianpilar.co.id' && $password === 'operator123') {
            $kantor = $kantorData[$kantorId] ?? $kantorData['pku'];
            Session::put('user_name', $kantor['opNama']);
            Session::put('user_email', $email);
            Session::put('user_role', 'Operator');
            Session::put('user_type', 'operator');
            Session::put('kantor_id', $kantorId);
            Session::put('kantor_name', $kantor['short']);
            return redirect()->route('dashboard');
        }

        return back()->withErrors(['Email atau kata sandi operator salah. Gunakan: operator@dianpilar.co.id / operator123']);
    }

    public function logout()
    {
        Session::flush();
        return redirect()->route('login');
    }

    // ============================================================
    // PAGES
    // ============================================================
    public function dashboard()
    {
        $kantorData = $this->getKantorData();
        $aset  = $this->getActiveAset();
        $stat  = $this->getActiveStat();
        $isAdmin = Session::get('user_type') === 'admin';
        $kantorLabel = $isAdmin ? 'Semua Kantor' : ($kantorData[Session::get('kantor_id', 'pku')]['nama'] ?? 'Kantor');

        return view('pages.dashboard', array_merge($this->sharedViewData(), [
            'aset'        => $aset,
            'stat'        => $stat,
            'kantorLabel' => $kantorLabel,
        ]));
    }

    public function inventaris(Request $request)
    {
        $aset = $this->getActiveAset();

        // Filter
        if ($q = $request->get('q')) {
            $aset = array_filter($aset, fn($a) =>
                stripos($a['nama'], $q) !== false ||
                stripos($a['kode'], $q) !== false ||
                stripos($a['kategori'], $q) !== false
            );
        }
        if ($kondisi = $request->get('kondisi')) {
            $aset = array_filter($aset, fn($a) => $a['kondisi'] === $kondisi);
        }
        if ($kategori = $request->get('kategori')) {
            $aset = array_filter($aset, fn($a) => $a['kategori'] === $kategori);
        }
        if ($kantor = $request->get('kantor')) {
            $aset = array_filter($aset, fn($a) => $a['kantor'] === $kantor);
        }

        return view('pages.inventaris', array_merge($this->sharedViewData(), [
            'aset' => array_values($aset),
        ]));
    }

    public function tambahBarang()
    {
        return view('pages.tambah-barang', $this->sharedViewData());
    }

    public function mutasi()
    {
        $mutasiList = [
            ['id'=>'MUT-001','aset'=>'Laptop Dell Precision','kode'=>'DPU-3101','asal'=>'Tebet Jakarta','tujuan'=>'Surabaya','pengaju'=>'Arif Budiman','tanggal'=>'15 Apr 2025','status'=>'Disetujui'],
            ['id'=>'MUT-002','aset'=>'AC Split 2PK Daikin','kode'=>'DPU-2202','asal'=>'Pekanbaru','tujuan'=>'Bekasi','pengaju'=>'Rina Amelia','tanggal'=>'14 Apr 2025','status'=>'Menunggu'],
            ['id'=>'MUT-003','aset'=>'Proyektor Epson EB-X49','kode'=>'DPU-2204','asal'=>'Pekanbaru','tujuan'=>'Tebet Jakarta','pengaju'=>'Rina Amelia','tanggal'=>'13 Apr 2025','status'=>'Ditolak'],
            ['id'=>'MUT-004','aset'=>'UPS APC 3000VA','kode'=>'DPU-3103','asal'=>'Tebet Jakarta','tujuan'=>'Pekanbaru','pengaju'=>'Arif Budiman','tanggal'=>'12 Apr 2025','status'=>'Menunggu'],
            ['id'=>'MUT-005','aset'=>'Scaffolding Set (50 unit)','kode'=>'DPU-5103','asal'=>'Bekasi','tujuan'=>'Surabaya','pengaju'=>'Hendra Susanto','tanggal'=>'10 Apr 2025','status'=>'Disetujui'],
        ];
        return view('pages.mutasi', array_merge($this->sharedViewData(), compact('mutasiList')));
    }

    public function jadwal()
    {
        $jadwalList = [
            ['id'=>'JDW-001','aset'=>'Genset 500kVA Perkins','kantor'=>'Pekanbaru','jenis'=>'Penggantian Alternator','teknisi'=>'Pak Budiono','tanggal'=>'18 Apr 2025','waktu'=>'09:00 - 12:00','status'=>'Dalam Proses'],
            ['id'=>'JDW-002','aset'=>'Lift A1 - Lobby','kantor'=>'Pekanbaru','jenis'=>'Servis Rutin Bulanan','teknisi'=>'CV. Lift Jaya','tanggal'=>'18 Apr 2025','waktu'=>'13:00 - 15:00','status'=>'Terjadwal'],
            ['id'=>'JDW-003','aset'=>'AC Split 2PK Daikin','kantor'=>'Pekanbaru','jenis'=>'Perbaikan Kompresor','teknisi'=>'Daikin Service','tanggal'=>'22 Apr 2025','waktu'=>'09:00 - 11:00','status'=>'Terjadwal'],
            ['id'=>'JDW-004','aset'=>'Forklift Komatsu FG15','kantor'=>'Bekasi','jenis'=>'Pemeriksaan Tahunan','teknisi'=>'PT. Komatsu Indo','tanggal'=>'25 Apr 2025','waktu'=>'08:00 - 16:00','status'=>'Terjadwal'],
            ['id'=>'JDW-005','aset'=>'Concrete Mixer Molen 500L','kantor'=>'Bekasi','jenis'=>'Penggantian Gear Box','teknisi'=>'Bengkel Mitra','tanggal'=>'30 Apr 2025','waktu'=>'08:00 - 17:00','status'=>'Terjadwal'],
            ['id'=>'JDW-006','aset'=>'Total Station Topcon ES-103','kantor'=>'Surabaya','jenis'=>'Kalibrasi Tahunan','teknisi'=>'Topcon Indonesia','tanggal'=>'2 Mei 2025','waktu'=>'10:00 - 12:00','status'=>'Terjadwal'],
            ['id'=>'JDW-007','aset'=>'Proyektor Epson EB-X49','kantor'=>'Pekanbaru','jenis'=>'Pembersihan Lensa','teknisi'=>'Tim Internal','tanggal'=>'5 Apr 2025','waktu'=>'10:00 - 11:00','status'=>'Selesai'],
            ['id'=>'JDW-008','aset'=>'UPS APC 3000VA','kantor'=>'Tebet Jakarta','jenis'=>'Penggantian Baterai','teknisi'=>'APC Partner','tanggal'=>'10 Apr 2025','waktu'=>'09:00 - 11:00','status'=>'Terlewat'],
        ];
        return view('pages.jadwal', array_merge($this->sharedViewData(), compact('jadwalList')));
    }

    public function stok()
    {
        $kantorData = $this->getKantorData();
        $stokList = [];
        if (Session::get('user_type') === 'admin') {
            foreach ($kantorData as $data) {
                foreach ($data['stok'] as $s) $stokList[] = $s;
            }
        } else {
            $kantorId = Session::get('kantor_id', 'pku');
            $stokList = $kantorData[$kantorId]['stok'] ?? [];
        }
        return view('pages.stok', array_merge($this->sharedViewData(), compact('stokList')));
    }

    public function qrLabel()
    {
        return view('pages.qr-label', $this->sharedViewData());
    }

    public function laporan()
    {
        return view('pages.laporan', $this->sharedViewData());
    }

    public function manajemenUser()
    {
        $userList = [
            ['nama'=>'Ahmad Santoso','email'=>'admin@dianpilar.co.id','peran'=>'Admin','kantor'=>'Semua Kantor','last_login'=>'15 Apr 2025, 08:02','bergabung'=>'Jan 2023','initials'=>'AS','color1'=>'#f97316','color2'=>'#c2410c'],
            ['nama'=>'Rina Amelia','email'=>'rina@dianpilar.co.id','peran'=>'Operator','kantor'=>'Pekanbaru','last_login'=>'15 Apr 2025, 09:15','bergabung'=>'Mar 2023','initials'=>'RA','color1'=>'#2563eb','color2'=>'#1d4ed8'],
            ['nama'=>'Arif Budiman','email'=>'arif@dianpilar.co.id','peran'=>'Operator','kantor'=>'Tebet Jakarta','last_login'=>'15 Apr 2025, 10:30','bergabung'=>'Mar 2023','initials'=>'AB','color1'=>'#16a34a','color2'=>'#15803d'],
            ['nama'=>'Dewi Lestari','email'=>'dewi@dianpilar.co.id','peran'=>'Operator','kantor'=>'Surabaya','last_login'=>'14 Apr 2025, 16:45','bergabung'=>'Apr 2023','initials'=>'DL','color1'=>'#7c3aed','color2'=>'#6d28d9'],
            ['nama'=>'Hendra Susanto','email'=>'hendra@dianpilar.co.id','peran'=>'Operator','kantor'=>'Bekasi','last_login'=>'14 Apr 2025, 14:20','bergabung'=>'Apr 2023','initials'=>'HS','color1'=>'#dc2626','color2'=>'#b91c1c'],
            ['nama'=>'Sari Dewi','email'=>'sari@dianpilar.co.id','peran'=>'Operator','kantor'=>'Pekanbaru','last_login'=>'13 Apr 2025, 11:30','bergabung'=>'May 2023','initials'=>'SD','color1'=>'#0891b2','color2'=>'#0e7490'],
        ];
        return view('pages.manajemen-user', array_merge($this->sharedViewData(), compact('userList')));
    }

    public function auditLog()
    {
        $auditLogs = [
            ['user'=>'Ahmad Santoso','aksi'=>'Login ke sistem','waktu'=>'15 Apr 2025, 08:02','icon'=>'login','bg'=>'#f8fafc','ic'=>'#94a3b8','modul'=>'Auth'],
            ['user'=>'Rina Amelia','aksi'=>'Menambahkan aset: AC Split Daikin — Pekanbaru','waktu'=>'15 Apr 2025, 09:15','icon'=>'add_circle','bg'=>'#f0fdf4','ic'=>'#16a34a','modul'=>'Inventaris'],
            ['user'=>'Arif Budiman','aksi'=>'Mengajukan mutasi: Laptop → Surabaya','waktu'=>'15 Apr 2025, 10:30','icon'=>'swap_horiz','bg'=>'#fff7ed','ic'=>'#f97316','modul'=>'Mutasi'],
            ['user'=>'Ahmad Santoso','aksi'=>'Menyetujui mutasi: Laptop Dell Precision','waktu'=>'15 Apr 2025, 11:00','icon'=>'check_circle','bg'=>'#f0fdf4','ic'=>'#16a34a','modul'=>'Mutasi'],
            ['user'=>'Hendra Susanto','aksi'=>'Mengubah kondisi: Genset Mobile 100kVA → Rusak','waktu'=>'14 Apr 2025, 16:45','icon'=>'edit','bg'=>'#fef2f2','ic'=>'#ef4444','modul'=>'Inventaris'],
            ['user'=>'Dewi Lestari','aksi'=>'Mengubah kondisi: Laptop Dell Latitude → Rusak','waktu'=>'14 Apr 2025, 14:20','icon'=>'edit','bg'=>'#fef2f2','ic'=>'#ef4444','modul'=>'Inventaris'],
            ['user'=>'Rina Amelia','aksi'=>'Membuat permintaan pengadaan: Toner Printer x10','waktu'=>'13 Apr 2025, 11:30','icon'=>'add_shopping_cart','bg'=>'#eff6ff','ic'=>'#2563eb','modul'=>'Stok'],
            ['user'=>'Ahmad Santoso','aksi'=>'Menambahkan pengguna baru: Sari Dewi','waktu'=>'13 Apr 2025, 10:00','icon'=>'person_add','bg'=>'#f5f3ff','ic'=>'#7c3aed','modul'=>'User'],
            ['user'=>'Arif Budiman','aksi'=>'Login ke sistem dari perangkat baru','waktu'=>'12 Apr 2025, 08:30','icon'=>'warning','bg'=>'#fefce8','ic'=>'#ca8a04','modul'=>'Auth'],
            ['user'=>'Ahmad Santoso','aksi'=>'Mengekspor laporan inventaris April 2025','waktu'=>'12 Apr 2025, 09:15','icon'=>'download','bg'=>'#f8fafc','ic'=>'#64748b','modul'=>'Laporan'],
        ];
        return view('pages.audit-log', array_merge($this->sharedViewData(), compact('auditLogs')));
    }

    public function pengaturan()
    {
        return view('pages.pengaturan', $this->sharedViewData());
    }
}
