<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Login | Sistem Inventaris DPU</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
<style>
*{font-family:'DM Sans',sans-serif;box-sizing:border-box;margin:0;padding:0;}
h1,h2,h3{font-family:'Sora',sans-serif;}
.material-symbols-outlined{font-variation-settings:'FILL' 0,'wght' 400,'GRAD' 0,'opsz' 24;font-size:20px;vertical-align:middle;}
.fill-icon{font-variation-settings:'FILL' 1,'wght' 400,'GRAD' 0,'opsz' 24;}
.field{width:100%;background:#f8fafc;border:1.5px solid #e2e8f0;border-radius:10px;padding:10px 14px;font-size:13px;transition:all .15s;outline:none;color:#0f172a;}
.field:focus{border-color:#f97316;background:#fff;box-shadow:0 0 0 3px rgba(249,115,22,.1);}
.btn-or{background:linear-gradient(135deg,#f97316,#ea580c);color:#fff;font-weight:700;border-radius:12px;padding:12px 22px;font-size:13px;transition:all .18s;box-shadow:0 4px 14px rgba(249,115,22,0.25);border:none;cursor:pointer;width:100%;display:flex;align-items:center;justify-content:center;gap:8px;}
.btn-or:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(249,115,22,0.35);}
.login-card{background:#fff;border-radius:20px;padding:32px;box-shadow:0 8px 40px rgba(0,0,0,.09);border:1px solid #f1f5f9;}
.tab-btn{padding:8px 20px;font-size:13px;font-weight:600;border:1.5px solid #e2e8f0;cursor:pointer;border-radius:10px;transition:all .15s;background:#fff;color:#64748b;}
.tab-btn.active{background:linear-gradient(135deg,#f97316,#ea580c);color:#fff;border-color:transparent;box-shadow:0 4px 12px rgba(249,115,22,.3);}
@keyframes fadeIn{from{opacity:0;transform:translateY(10px);}to{opacity:1;transform:translateY(0);}}
.fade-in{animation:fadeIn .3s ease forwards;}
</style>
</head>
<body style="background:#f8f8f6;min-height:100vh;display:flex;overflow:hidden;">

<!-- Panel Kiri -->
<section class="hidden lg:flex" style="width:42%;background:linear-gradient(145deg,#0f172a 0%,#1e293b 55%,#0f172a 100%);padding:48px;flex-direction:column;justify-content:space-between;position:relative;overflow:hidden;">
  <!-- BG decorations -->
  <div style="position:absolute;top:-80px;left:-80px;width:400px;height:400px;background:rgba(249,115,22,.07);border-radius:50%;filter:blur(100px);"></div>
  <div style="position:absolute;bottom:-60px;right:-60px;width:350px;height:350px;background:rgba(234,88,12,.09);border-radius:50%;filter:blur(120px);"></div>
  <div style="position:absolute;inset:0;opacity:.03;background-image:radial-gradient(#f97316 1px,transparent 1px);background-size:30px 30px;pointer-events:none;"></div>
  <div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,transparent,#f97316,transparent);"></div>

  <div style="position:relative;z-index:1;">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:48px;">
      <div style="width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#f97316,#c2410c);display:flex;align-items:center;justify-content:center;font-family:'Sora',sans-serif;font-weight:800;font-size:16px;color:#fff;box-shadow:0 6px 20px rgba(249,115,22,.4);">DPU</div>
      <div>
        <div style="font-family:'Sora',sans-serif;font-weight:800;font-size:15px;color:#fff;">Dian Pilar Utama</div>
        <div style="font-size:10px;font-weight:600;color:rgba(249,115,22,.7);text-transform:uppercase;letter-spacing:.1em;margin-top:2px;">Sistem Inventaris v3</div>
      </div>
    </div>
    <h1 style="font-weight:800;font-size:42px;color:#fff;line-height:1.15;margin-bottom:16px;">Kelola Aset.<br/><span style="color:#f97316;">Efisien.</span><br/>Terpusat.</h1>
    <p style="color:#94a3b8;font-size:14px;line-height:1.7;max-width:340px;">Platform manajemen inventaris terpadu untuk seluruh cabang PT. Dian Pilar Utama — dari Pekanbaru hingga seluruh nusantara.</p>
  </div>

  <div style="position:relative;z-index:1;">
    <div style="display:flex;gap:32px;margin-bottom:28px;">
      <div><div style="font-family:'Sora',sans-serif;font-size:28px;font-weight:800;color:#fff;">1.2K+</div><div style="font-size:11px;color:#475569;font-weight:600;text-transform:uppercase;letter-spacing:.07em;">Aset Terdaftar</div></div>
      <div><div style="font-family:'Sora',sans-serif;font-size:28px;font-weight:800;color:#fff;">4</div><div style="font-size:11px;color:#475569;font-weight:600;text-transform:uppercase;letter-spacing:.07em;">Kantor Aktif</div></div>
      <div><div style="font-family:'Sora',sans-serif;font-size:28px;font-weight:800;color:#fff;">99.8%</div><div style="font-size:11px;color:#475569;font-weight:600;text-transform:uppercase;letter-spacing:.07em;">Uptime</div></div>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:8px;">
      @foreach(['Pekanbaru','Tebet Jakarta','Surabaya','Bekasi'] as $k)
      <span style="padding:5px 14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:999px;color:#94a3b8;font-size:11px;font-weight:600;">{{ $k }}</span>
      @endforeach
    </div>
  </div>
</section>

<!-- Panel Kanan -->
<section style="flex:1;display:flex;flex-direction:column;justify-content:center;align-items:center;padding:32px 24px;position:relative;">
  <div style="position:absolute;top:0;right:0;width:300px;height:300px;background:rgba(249,115,22,.04);border-radius:0 0 0 50%;pointer-events:none;"></div>

  <div style="width:100%;max-width:420px;position:relative;z-index:1;">
    <!-- Logo mobile -->
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:28px;" class="lg:hidden">
      <div style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#f97316,#c2410c);display:flex;align-items:center;justify-content:center;font-family:'Sora',sans-serif;font-weight:800;font-size:13px;color:#fff;">DPU</div>
      <div style="font-family:'Sora',sans-serif;font-weight:800;font-size:15px;color:#0f172a;">Dian Pilar Utama</div>
    </div>

    <!-- Tab Switch -->
    <div style="display:flex;gap:8px;margin-bottom:20px;background:#f1f5f9;padding:5px;border-radius:13px;">
      <button class="tab-btn active" id="tab-admin" onclick="switchTab('admin')" style="flex:1;">Admin</button>
      <button class="tab-btn" id="tab-operator" onclick="switchTab('operator')" style="flex:1;">Operator</button>
    </div>

    @if($errors->any())
    <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:10px;padding:12px 14px;margin-bottom:16px;font-size:12px;color:#991b1b;font-weight:600;">
      <span class="material-symbols-outlined fill-icon" style="font-size:14px;color:#ef4444;">error</span>
      {{ $errors->first() }}
    </div>
    @endif

    <!-- FORM ADMIN -->
    <div id="form-admin" class="login-card fade-in">
      <h2 style="font-weight:800;font-size:22px;color:#0f172a;margin-bottom:4px;">Selamat Datang!</h2>
      <p style="font-size:13px;color:#64748b;margin-bottom:20px;">Akses penuh ke semua kantor & data.</p>
      <form method="POST" action="{{ route('login.post') }}" style="display:flex;flex-direction:column;gap:14px;">
        @csrf
        <input type="hidden" name="role" value="admin"/>
        <div>
          <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Email</label>
          <div style="position:relative;">
            <span class="material-symbols-outlined" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:18px;">person</span>
            <input type="email" name="email" placeholder="admin@dianpilar.co.id" class="field" style="padding-left:42px;" value="admin@dianpilar.co.id"/>
          </div>
        </div>
        <div>
          <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Kata Sandi</label>
          <div style="position:relative;">
            <span class="material-symbols-outlined" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:18px;">lock</span>
            <input id="admin-pass" type="password" name="password" placeholder="Kata sandi" class="field" style="padding-left:42px;padding-right:42px;" value="admin123"/>
            <button type="button" onclick="togglePass('admin-pass',this)" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);border:none;background:none;cursor:pointer;color:#94a3b8;"><span class="material-symbols-outlined" style="font-size:18px;">visibility</span></button>
          </div>
        </div>
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:10px 14px;font-size:11px;color:#166534;">
          <strong>Demo:</strong> admin@dianpilar.co.id / admin123
        </div>
        <button type="submit" class="btn-or">
          <span class="material-symbols-outlined fill-icon" style="font-size:18px;">login</span> Masuk ke Sistem
        </button>
      </form>
    </div>

    <!-- FORM OPERATOR -->
    <div id="form-operator" class="login-card fade-in" style="display:none;">
      <h2 style="font-weight:800;font-size:22px;color:#0f172a;margin-bottom:4px;">Login Operator</h2>
      <p style="font-size:13px;color:#64748b;margin-bottom:20px;">Akses terbatas per kantor.</p>
      <form method="POST" action="{{ route('login.post') }}" style="display:flex;flex-direction:column;gap:14px;">
        @csrf
        <input type="hidden" name="role" value="operator"/>
        <div>
          <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Pilih Kantor</label>
          <select name="kantor" class="field">
            <option value="pku">Kantor Pusat Pekanbaru</option>
            <option value="jkt">Kantor Proyek Tebet Jakarta</option>
            <option value="sby">Kantor Proyek Surabaya</option>
            <option value="bks">Kantor Proyek Bekasi</option>
          </select>
        </div>
        <div>
          <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Email</label>
          <div style="position:relative;">
            <span class="material-symbols-outlined" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:18px;">person</span>
            <input type="email" name="email" placeholder="operator@dianpilar.co.id" class="field" style="padding-left:42px;" value="operator@dianpilar.co.id"/>
          </div>
        </div>
        <div>
          <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Kata Sandi</label>
          <div style="position:relative;">
            <span class="material-symbols-outlined" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:18px;">lock</span>
            <input id="op-pass" type="password" name="password" placeholder="Kata sandi" class="field" style="padding-left:42px;padding-right:42px;" value="operator123"/>
            <button type="button" onclick="togglePass('op-pass',this)" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);border:none;background:none;cursor:pointer;color:#94a3b8;"><span class="material-symbols-outlined" style="font-size:18px;">visibility</span></button>
          </div>
        </div>
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:10px 14px;font-size:11px;color:#166534;">
          <strong>Demo:</strong> operator@dianpilar.co.id / operator123
        </div>
        <button type="submit" class="btn-or">
          <span class="material-symbols-outlined fill-icon" style="font-size:18px;">login</span> Masuk ke Sistem
        </button>
      </form>
    </div>
  </div>
</section>

<script>
function switchTab(tab) {
  const isAdmin = tab === 'admin';
  document.getElementById('form-admin').style.display = isAdmin ? 'block' : 'none';
  document.getElementById('form-operator').style.display = isAdmin ? 'none' : 'block';
  document.getElementById('tab-admin').className = 'tab-btn' + (isAdmin ? ' active' : '');
  document.getElementById('tab-operator').className = 'tab-btn' + (!isAdmin ? ' active' : '');
}
function togglePass(id, btn) {
  const inp = document.getElementById(id);
  const icon = btn.querySelector('.material-symbols-outlined');
  if(inp.type === 'password') { inp.type = 'text'; icon.textContent = 'visibility_off'; }
  else { inp.type = 'password'; icon.textContent = 'visibility'; }
}
</script>
</body>
</html>
