<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Sistem Inventaris | PT. Dian Pilar Utama</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
<style>
*{font-family:'DM Sans',sans-serif;box-sizing:border-box;}
h1,h2,h3,.font-head{font-family:'Sora',sans-serif;}
.material-symbols-outlined{font-variation-settings:'FILL' 0,'wght' 400,'GRAD' 0,'opsz' 24;font-size:20px;vertical-align:middle;}
.fill-icon{font-variation-settings:'FILL' 1,'wght' 400,'GRAD' 0,'opsz' 24;}

aside::-webkit-scrollbar{width:3px;}
aside::-webkit-scrollbar-thumb{background:rgba(249,115,22,0.25);border-radius:8px;}

.nav-item{display:flex;align-items:center;gap:10px;padding:9px 14px;border-radius:10px;color:#64748b;font-size:13px;font-weight:500;transition:all .15s ease;cursor:pointer;border:1px solid transparent;text-decoration:none;}
.nav-item:hover{background:#fff7ed;color:#ea580c;border-color:#fed7aa;}
.nav-item.active{background:linear-gradient(135deg,#f97316,#ea580c);color:#fff;font-weight:700;box-shadow:0 4px 14px rgba(249,115,22,0.3);}
.nav-item.active .material-symbols-outlined{color:#fff;}
.nav-group-label{font-size:10px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#cbd5e1;padding:14px 14px 5px;}

.toast{position:fixed;bottom:24px;right:24px;z-index:300;transform:translateY(80px);opacity:0;transition:all .3s cubic-bezier(.34,1.56,.64,1);}
.toast.show{transform:translateY(0);opacity:1;}

.modal{display:none;position:fixed;inset:0;background:rgba(15,23,42,0.5);z-index:200;align-items:center;justify-content:center;backdrop-filter:blur(4px);}
.modal.open{display:flex;}

@keyframes fadeUp{from{opacity:0;transform:translateY(12px);}to{opacity:1;transform:translateY(0);}}
.fade-up{animation:fadeUp .25s ease forwards;}

.btn-or{background:linear-gradient(135deg,#f97316,#ea580c);color:#fff;font-weight:700;border-radius:12px;padding:10px 22px;font-size:13px;transition:all .18s;box-shadow:0 4px 14px rgba(249,115,22,0.25);border:none;cursor:pointer;display:inline-flex;align-items:center;gap:6px;text-decoration:none;}
.btn-or:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(249,115,22,0.35);color:#fff;}
.btn-ghost{background:#f1f5f9;color:#475569;font-weight:600;border-radius:12px;padding:10px 22px;font-size:13px;transition:all .15s;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:6px;text-decoration:none;}
.btn-ghost:hover{background:#e2e8f0;color:#475569;}

.card{background:#fff;border-radius:16px;border:1px solid #f1f5f9;box-shadow:0 1px 4px rgba(0,0,0,.05);}
.card-stat{background:#fff;border-radius:16px;border:1px solid #f1f5f9;padding:20px;box-shadow:0 1px 4px rgba(0,0,0,.05);}

.field{width:100%;background:#f8fafc;border:1.5px solid #e2e8f0;border-radius:10px;padding:10px 14px;font-size:13px;transition:all .15s;outline:none;color:#0f172a;}
.field:focus{border-color:#f97316;background:#fff;box-shadow:0 0 0 3px rgba(249,115,22,.1);}
.field:disabled{background:#f1f5f9;cursor:not-allowed;opacity:.7;}
select.field{cursor:pointer;}

.badge-baik{background:#dcfce7;color:#166534;border:1px solid #bbf7d0;padding:2px 10px;border-radius:999px;font-size:10px;font-weight:700;}
.badge-rusak{background:#fee2e2;color:#991b1b;border:1px solid #fecaca;padding:2px 10px;border-radius:999px;font-size:10px;font-weight:700;}
.badge-perbaikan{background:#fef9c3;color:#854d0e;border:1px solid #fef08a;padding:2px 10px;border-radius:999px;font-size:10px;font-weight:700;}

.tbl th{padding:10px 16px;text-align:left;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.07em;background:#f8fafc;border-bottom:1px solid #f1f5f9;}
.tbl td{padding:12px 16px;font-size:13px;border-bottom:1px solid #f8fafc;color:#334155;}
.tbl tr:hover td{background:#fff7ed;}
.tbl tr:last-child td{border-bottom:none;}

.progress-track{height:6px;background:#f1f5f9;border-radius:999px;overflow:hidden;}
.progress-fill{height:100%;border-radius:999px;background:linear-gradient(90deg,#f97316,#ea580c);}

.stat-accent-border{border-left:3px solid #f97316;}
</style>
</head>
<body style="background:#f8f8f6;color:#0f172a;overflow-x:hidden;">

<div style="display:flex;min-height:100vh;">
  <!-- Sidebar -->
  <aside style="width:240px;min-height:100vh;background:linear-gradient(180deg,#0f172a 0%,#1e293b 100%);display:flex;flex-direction:column;position:fixed;top:0;left:0;overflow-y:auto;z-index:100;">
    <!-- Header -->
    <div style="padding:20px;border-bottom:1px solid rgba(249,115,22,.15);">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
        <div style="width:38px;height:38px;border-radius:10px;background:linear-gradient(135deg,#f97316,#c2410c);display:flex;align-items:center;justify-content:center;font-family:'Sora',sans-serif;font-weight:800;font-size:13px;color:#fff;flex-shrink:0;box-shadow:0 4px 12px rgba(249,115,22,.4);">DPU</div>
        <div>
          <div style="font-family:'Sora',sans-serif;font-weight:800;font-size:13px;color:#fff;line-height:1.2;">Dian Pilar Utama</div>
          <div style="font-size:10px;color:rgba(249,115,22,.7);font-weight:600;text-transform:uppercase;letter-spacing:.08em;">Inventaris v3</div>
        </div>
      </div>
      <!-- User Info -->
      <div style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:10px 12px;display:flex;align-items:center;gap:10px;">
        <div style="width:34px;height:34px;border-radius:9px;background:linear-gradient(135deg,#f97316,#c2410c);display:flex;align-items:center;justify-content:center;font-family:'Sora',sans-serif;font-weight:800;font-size:12px;color:#fff;flex-shrink:0;">
          {{ strtoupper(substr(session('user_name', 'U'), 0, 2)) }}
        </div>
        <div style="min-width:0;flex:1;">
          <div style="font-size:12px;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{{ session('user_name', 'User') }}</div>
          <div style="font-size:10px;color:#64748b;font-weight:500;">{{ session('user_role', 'Operator') }}</div>
        </div>
      </div>
      @if(session('user_type') === 'operator')
      <div style="margin-top:8px;background:rgba(249,115,22,.1);border:1px solid rgba(249,115,22,.2);border-radius:8px;padding:6px 10px;display:flex;align-items:center;gap:6px;">
        <span class="material-symbols-outlined" style="color:#f97316;font-size:13px;">location_on</span>
        <span style="font-size:11px;color:#fb923c;font-weight:600;">{{ session('kantor_name', '') }}</span>
      </div>
      @endif
    </div>

    <!-- Nav -->
    <nav style="padding:12px 10px;flex:1;display:flex;flex-direction:column;gap:2px;">
      <div class="nav-group-label">Menu Utama</div>
      <a href="{{ route('dashboard') }}" class="nav-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
        <span class="material-symbols-outlined fill-icon">dashboard</span> Dashboard
      </a>
      <a href="{{ route('inventaris') }}" class="nav-item {{ request()->routeIs('inventaris') ? 'active' : '' }}">
        <span class="material-symbols-outlined">inventory_2</span> Inventaris
      </a>
      <a href="{{ route('tambah-barang') }}" class="nav-item {{ request()->routeIs('tambah-barang') ? 'active' : '' }}">
        <span class="material-symbols-outlined">add_box</span> Tambah Barang
      </a>
      <a href="{{ route('mutasi') }}" class="nav-item {{ request()->routeIs('mutasi') ? 'active' : '' }}">
        <span class="material-symbols-outlined">swap_horiz</span> Mutasi Aset
      </a>
      <a href="{{ route('jadwal') }}" class="nav-item {{ request()->routeIs('jadwal') ? 'active' : '' }}">
        <span class="material-symbols-outlined">event</span> Jadwal Pemeliharaan
      </a>
      <a href="{{ route('stok') }}" class="nav-item {{ request()->routeIs('stok') ? 'active' : '' }}">
        <span class="material-symbols-outlined">shelves</span> Manajemen Stok
      </a>
      <a href="{{ route('qr-label') }}" class="nav-item {{ request()->routeIs('qr-label') ? 'active' : '' }}">
        <span class="material-symbols-outlined">qr_code_2</span> QR & Label
      </a>
      <a href="{{ route('laporan') }}" class="nav-item {{ request()->routeIs('laporan') ? 'active' : '' }}">
        <span class="material-symbols-outlined">bar_chart</span> Laporan
      </a>

      @if(session('user_type') === 'admin')
      <div class="nav-group-label" style="margin-top:4px;">Admin</div>
      <a href="{{ route('manajemen-user') }}" class="nav-item {{ request()->routeIs('manajemen-user') ? 'active' : '' }}">
        <span class="material-symbols-outlined">manage_accounts</span> Manajemen User
      </a>
      <a href="{{ route('audit-log') }}" class="nav-item {{ request()->routeIs('audit-log') ? 'active' : '' }}">
        <span class="material-symbols-outlined">history</span> Audit Log
      </a>
      @endif

      <div class="nav-group-label" style="margin-top:4px;">Akun</div>
      <a href="{{ route('pengaturan') }}" class="nav-item {{ request()->routeIs('pengaturan') ? 'active' : '' }}">
        <span class="material-symbols-outlined">settings</span> Pengaturan
      </a>
      <a href="{{ route('logout') }}" class="nav-item" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
        <span class="material-symbols-outlined">logout</span> Keluar
      </a>
      <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display:none;">@csrf</form>
    </nav>

    <div style="padding:14px;border-top:1px solid rgba(255,255,255,.05);">
      <div style="font-size:10px;color:#334155;text-align:center;">Sistem Inventaris DPU v3.0</div>
    </div>
  </aside>

  <!-- Main Content -->
  <div style="margin-left:240px;flex:1;display:flex;flex-direction:column;min-height:100vh;">
    <!-- Header -->
    <header style="background:#fff;border-bottom:1px solid #f1f5f9;padding:12px 24px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:50;box-shadow:0 1px 4px rgba(0,0,0,.04);">
      <div style="position:relative;">
        <span class="material-symbols-outlined" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:16px;">search</span>
        <input type="text" placeholder="Cari aset, kode, kategori..." class="field" style="padding-left:38px;width:280px;font-size:12px;background:#f8fafc;" onkeydown="if(event.key==='Enter'){window.location.href='{{ route('inventaris') }}?q='+this.value}"/>
      </div>
      <div style="display:flex;align-items:center;gap:12px;">
        <button onclick="showToast('Tidak ada notifikasi baru')" style="position:relative;width:36px;height:36px;border-radius:10px;background:#f8fafc;border:1px solid #e2e8f0;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#64748b;">
          <span class="material-symbols-outlined" style="font-size:18px;">notifications</span>
          <span style="position:absolute;top:6px;right:6px;width:7px;height:7px;background:#f97316;border-radius:50%;border:1.5px solid #fff;"></span>
        </button>
        <div style="display:flex;align-items:center;gap:8px;cursor:pointer;" onclick="window.location.href='{{ route('pengaturan') }}'">
          <div style="width:34px;height:34px;border-radius:9px;background:linear-gradient(135deg,#f97316,#c2410c);display:flex;align-items:center;justify-content:center;font-family:'Sora',sans-serif;font-weight:800;font-size:12px;color:#fff;">
            {{ strtoupper(substr(session('user_name', 'U'), 0, 2)) }}
          </div>
          <div>
            <div style="font-size:12px;font-weight:700;color:#0f172a;">{{ session('user_name', 'User') }}</div>
            <div style="font-size:10px;color:#94a3b8;">{{ session('user_role', '') }}</div>
          </div>
        </div>
      </div>
    </header>

    <!-- Page Content -->
    <main style="flex:1;" class="fade-up">
      @yield('content')
    </main>
  </div>
</div>

<!-- Toast Notification -->
<div class="toast" id="toast">
  <div style="background:#fff;border-radius:14px;padding:14px 18px;box-shadow:0 8px 32px rgba(0,0,0,.12);display:flex;align-items:center;gap:12px;border-left:3px solid #f97316;min-width:260px;">
    <span class="material-symbols-outlined fill-icon" id="toast-icon" style="color:#10b981;font-size:20px;">check_circle</span>
    <span id="toast-msg" style="font-size:13px;font-weight:600;color:#0f172a;"></span>
  </div>
</div>

<!-- Detail Modal -->
<div class="modal" id="detail-modal">
  <div style="background:#fff;border-radius:20px;width:580px;max-width:95vw;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.18);">
    <div id="detail-modal-content"></div>
  </div>
</div>

<!-- Status Modal -->
<div class="modal" id="status-modal">
  <div style="background:#fff;border-radius:20px;width:400px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,.18);">
    <div style="padding:20px 24px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
      <div>
        <h3 style="font-family:'Sora',sans-serif;font-weight:800;font-size:16px;color:#0f172a;">Ubah Status Kondisi</h3>
        <p style="font-size:12px;color:#64748b;" id="status-modal-nama"></p>
      </div>
      <button onclick="closeModal('status-modal')" style="border:none;background:#f1f5f9;border-radius:8px;width:30px;height:30px;cursor:pointer;font-size:18px;color:#64748b;">×</button>
    </div>
    <div style="padding:20px 24px;display:flex;flex-direction:column;gap:10px;">
      @foreach(['Baik','Dalam Perbaikan','Rusak'] as $kondisi)
      <label style="display:flex;align-items:center;gap:12px;padding:14px;border-radius:12px;border:1.5px solid #e2e8f0;cursor:pointer;transition:all .15s;" onmouseover="this.style.borderColor='#f97316';this.style.background='#fff7ed'" onmouseout="this.style.borderColor='#e2e8f0';this.style.background='#fff'">
        <input type="radio" name="status-kondisi" value="{{ $kondisi }}" style="accent-color:#f97316;width:16px;height:16px;"/>
        <div>
          <p style="font-size:13px;font-weight:700;color:#0f172a;">{{ $kondisi }}</p>
          <p style="font-size:11px;color:#94a3b8;">{{ $kondisi === 'Baik' ? 'Aset berfungsi normal, siap digunakan' : ($kondisi === 'Dalam Perbaikan' ? 'Sedang diperbaiki atau dalam pemeliharaan' : 'Aset tidak dapat digunakan, perlu tindakan') }}</p>
        </div>
      </label>
      @endforeach
    </div>
    <div style="padding:0 24px 20px;display:flex;gap:10px;">
      <button onclick="closeModal('status-modal')" class="btn-ghost" style="flex:1;">Batal</button>
      <button onclick="closeModal('status-modal');showToast('Status berhasil diperbarui!')" class="btn-or" style="flex:1;justify-content:center;">Simpan</button>
    </div>
  </div>
</div>

<script>
function showToast(msg, type) {
  const toast = document.getElementById('toast');
  const icon = document.getElementById('toast-icon');
  document.getElementById('toast-msg').textContent = msg;
  if(type==='delete'){ icon.textContent='delete'; icon.style.color='#ef4444'; }
  else if(type==='warning'){ icon.textContent='warning'; icon.style.color='#f59e0b'; }
  else{ icon.textContent='check_circle'; icon.style.color='#10b981'; }
  toast.classList.add('show');
  setTimeout(()=>toast.classList.remove('show'),3000);
}
function openModal(id){ document.getElementById(id).classList.add('open'); }
function closeModal(id){ document.getElementById(id).classList.remove('open'); }

function showDetailModal(data) {
  document.getElementById('detail-modal-content').innerHTML = `
    <div style="padding:20px 24px;border-bottom:1px solid #f1f5f9;display:flex;align-items:flex-start;justify-content:space-between;gap:12px;">
      <div>
        <h3 style="font-family:'Sora',sans-serif;font-weight:800;font-size:16px;color:#0f172a;margin-bottom:4px;">${data.nama}</h3>
        <p style="font-size:12px;color:#94a3b8;">${data.kode} · ${data.kategori}</p>
      </div>
      <button onclick="closeModal('detail-modal')" style="border:none;background:#f1f5f9;border-radius:8px;width:30px;height:30px;cursor:pointer;font-size:18px;color:#64748b;flex-shrink:0;">×</button>
    </div>
    <div style="padding:20px;display:grid;grid-template-columns:1fr 1fr;gap:10px;">
      ${[['Nomor Seri',data.sn||'-'],['Nilai Aset','Rp '+data.nilai],['Kategori',data.kategori],['Kondisi',data.kondisi],['Penanggung Jawab',data.pj||'-'],['Tanggal Pengadaan',data.tanggal],['Ruangan',data.ruangan],['Catatan',data.catatan||'—']].map(([l,v])=>`
      <div style="background:#f8fafc;border-radius:12px;padding:12px 14px;border:1px solid #f1f5f9;">
        <p style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#94a3b8;margin-bottom:4px;">${l}</p>
        <p style="font-size:13px;font-weight:700;color:#0f172a;">${v}</p>
      </div>`).join('')}
    </div>
    <div style="padding:0 20px 20px;display:flex;gap:10px;">
      <button onclick="openModal('status-modal');closeModal('detail-modal');document.getElementById('status-modal-nama').textContent='${data.nama} — ${data.kode}'" class="btn-ghost" style="flex:1;justify-content:center;"><span class="material-symbols-outlined" style="font-size:16px;">edit</span> Ubah Status</button>
      <button onclick="closeModal('detail-modal');showToast('Fitur mutasi dibuka!')" class="btn-ghost" style="flex:1;justify-content:center;"><span class="material-symbols-outlined" style="font-size:16px;">swap_horiz</span> Mutasi</button>
      <button onclick="closeModal('detail-modal');showToast('QR Label disiapkan!')" class="btn-or" style="flex:1;justify-content:center;"><span class="material-symbols-outlined" style="font-size:16px;">qr_code</span> QR Label</button>
    </div>`;
  openModal('detail-modal');
}
</script>
@stack('scripts')
</body>
</html>
