@extends('layouts.app')

@section('content')
<div style="padding:24px;max-width:900px;display:flex;flex-direction:column;gap:16px;">
  <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;">
    <div>
      <h2 style="font-family:'Sora',sans-serif;font-weight:800;font-size:20px;color:#0f172a;margin-bottom:4px;">Catatan Audit</h2>
      <p style="font-size:13px;color:#64748b;">Rekam jejak aktivitas seluruh pengguna sistem</p>
    </div>
    <div style="display:flex;gap:8px;">
      <input type="text" placeholder="Cari aktivitas..." class="field" style="width:200px;font-size:12px;"/>
      <button onclick="showToast('Mengunduh log audit...')" class="btn-ghost" style="font-size:12px;padding:8px 14px;"><span class="material-symbols-outlined" style="font-size:15px;">download</span> Ekspor Log</button>
    </div>
  </div>

  <div class="card" style="overflow:hidden;">
    @foreach($auditLogs as $log)
    <div style="display:flex;align-items:flex-start;gap:14px;padding:14px 18px;border-bottom:1px solid #f8fafc;transition:background .12s;cursor:default;" onmouseover="this.style.background='#fff7ed'" onmouseout="this.style.background='transparent'">
      <div style="width:36px;height:36px;border-radius:10px;background:{{ $log['bg'] }};display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px;">
        <span class="material-symbols-outlined" style="color:{{ $log['ic'] }};font-size:17px;">{{ $log['icon'] }}</span>
      </div>
      <div style="flex:1;">
        <p style="font-size:13px;color:#0f172a;"><span style="font-weight:700;">{{ $log['user'] }}</span> {{ $log['aksi'] }}</p>
        <p style="font-size:11px;color:#94a3b8;margin-top:2px;">{{ $log['waktu'] }}</p>
      </div>
      <span style="font-size:10px;font-weight:700;color:#94a3b8;background:#f8fafc;padding:3px 8px;border-radius:6px;flex-shrink:0;border:1px solid #f1f5f9;">{{ $log['modul'] }}</span>
    </div>
    @endforeach
  </div>

  <!-- Pagination -->
  <div style="display:flex;align-items:center;justify-content:space-between;">
    <span style="font-size:12px;color:#94a3b8;">Menampilkan {{ count($auditLogs) }} entri</span>
    <div style="display:flex;gap:6px;">
      @foreach(range(1,4) as $p)
      <button style="width:32px;height:32px;border-radius:8px;border:1px solid {{ $p===1?'#f97316':'#e2e8f0' }};background:{{ $p===1?'#fff7ed':'#fff' }};color:{{ $p===1?'#f97316':'#64748b' }};font-size:12px;font-weight:700;cursor:pointer;">{{ $p }}</button>
      @endforeach
    </div>
  </div>
</div>
@endsection
