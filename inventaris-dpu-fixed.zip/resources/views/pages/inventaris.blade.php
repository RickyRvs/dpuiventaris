@extends('layouts.app')

@section('content')
<div style="padding:24px;display:flex;flex-direction:column;gap:16px;">
  <!-- Header -->
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
    <div>
      <h2 style="font-family:'Sora',sans-serif;font-weight:800;font-size:20px;color:#0f172a;margin-bottom:2px;">Daftar Inventaris</h2>
      <p style="font-size:13px;color:#64748b;">{{ count($aset) }} aset ditemukan</p>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;">
      <form method="GET" action="{{ route('inventaris') }}" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
        <div style="position:relative;">
          <span class="material-symbols-outlined" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:15px;">search</span>
          <input type="text" name="q" placeholder="Cari aset..." class="field" style="padding-left:34px;width:180px;font-size:12px;" value="{{ request('q') }}"/>
        </div>
        <select name="kondisi" class="field" style="width:auto;padding:8px 12px;font-size:12px;" onchange="this.form.submit()">
          <option value="">Semua Kondisi</option>
          <option value="Baik" {{ request('kondisi')==='Baik'?'selected':'' }}>Baik</option>
          <option value="Dalam Perbaikan" {{ request('kondisi')==='Dalam Perbaikan'?'selected':'' }}>Dalam Perbaikan</option>
          <option value="Rusak" {{ request('kondisi')==='Rusak'?'selected':'' }}>Rusak</option>
        </select>
        <select name="kategori" class="field" style="width:auto;padding:8px 12px;font-size:12px;" onchange="this.form.submit()">
          <option value="">Semua Kategori</option>
          @foreach(['Elektronik & IT','Furnitur Kantor','Kendaraan','Alat Berat','Infrastruktur','Peralatan Survey','Mekanikal & Elektrikal','Peralatan Konstruksi'] as $kat)
          <option value="{{ $kat }}" {{ request('kategori')===$kat?'selected':'' }}>{{ $kat }}</option>
          @endforeach
        </select>
        @if($isAdmin)
        <select name="kantor" class="field" style="width:auto;padding:8px 12px;font-size:12px;" onchange="this.form.submit()">
          <option value="">Semua Kantor</option>
          @foreach($kantorList as $id => $kantor)
          <option value="{{ $kantor['short'] }}" {{ request('kantor')===$kantor['short']?'selected':'' }}>{{ $kantor['short'] }}</option>
          @endforeach
        </select>
        @endif
      </form>
      <a href="{{ route('tambah-barang') }}" class="btn-or" style="font-size:12px;padding:8px 14px;">
        <span class="material-symbols-outlined" style="font-size:15px;">add</span> Tambah
      </a>
    </div>
  </div>

  <!-- Table -->
  <div class="card" style="overflow:hidden;">
    @if(count($aset) === 0)
    <div style="padding:60px;text-align:center;color:#94a3b8;">
      <span class="material-symbols-outlined" style="font-size:48px;display:block;margin-bottom:12px;color:#cbd5e1;">inventory_2</span>
      <p style="font-size:14px;font-weight:600;">Tidak ada aset ditemukan</p>
      <p style="font-size:12px;margin-top:4px;">Coba ubah filter pencarian</p>
    </div>
    @else
    <table class="tbl" style="width:100%;">
      <thead><tr>
        <th style="padding-left:20px;">Kode</th>
        <th>Nama Aset</th>
        <th>Kategori</th>
        <th>{{ $isAdmin ? 'Kantor' : 'Ruangan' }}</th>
        <th>Kondisi</th>
        <th>Nilai (Rp)</th>
        <th>Aksi</th>
      </tr></thead>
      <tbody>
        @foreach($aset as $a)
        <tr>
          <td style="padding-left:20px;font-size:11px;color:#94a3b8;font-weight:700;">{{ $a['kode'] }}</td>
          <td>
            <div style="display:flex;align-items:center;gap:10px;">
              <div style="width:32px;height:32px;background:{{ $a['kondisi']==='Baik'?'#dcfce7':($a['kondisi']==='Rusak'?'#fee2e2':'#fef9c3') }};border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                <span class="material-symbols-outlined fill-icon" style="color:{{ $a['kondisi']==='Baik'?'#16a34a':($a['kondisi']==='Rusak'?'#dc2626':'#ca8a04') }};font-size:15px;">{{ $a['kondisi']==='Baik'?'check_circle':($a['kondisi']==='Rusak'?'cancel':'build') }}</span>
              </div>
              <div>
                <div style="font-size:13px;font-weight:700;color:#0f172a;">{{ $a['nama'] }}</div>
                <div style="font-size:11px;color:#94a3b8;">PJ: {{ $a['pj'] }}</div>
              </div>
            </div>
          </td>
          <td style="font-size:12px;color:#64748b;">{{ $a['kategori'] }}</td>
          <td style="font-size:12px;color:#64748b;">{{ $isAdmin ? $a['kantor'] : $a['ruangan'] }}</td>
          <td>
            @if($a['kondisi'] === 'Baik')
              <span class="badge-baik">Baik</span>
            @elseif($a['kondisi'] === 'Rusak')
              <span class="badge-rusak">Rusak</span>
            @else
              <span class="badge-perbaikan">Dalam Perbaikan</span>
            @endif
          </td>
          <td style="font-size:13px;font-weight:700;color:#0f172a;">{{ number_format(str_replace('.','',$a['nilai'])) }}</td>
          <td>
            <div style="display:flex;gap:6px;">
              <button onclick='showDetailModal({{ json_encode($a) }})' style="background:#f8fafc;border:1px solid #e2e8f0;color:#64748b;padding:5px 10px;border-radius:8px;cursor:pointer;font-size:11px;font-weight:600;display:flex;align-items:center;gap:4px;" onmouseover="this.style.background='#fff7ed';this.style.color='#f97316'" onmouseout="this.style.background='#f8fafc';this.style.color='#64748b'">
                <span class="material-symbols-outlined" style="font-size:14px;">visibility</span> Detail
              </button>
              <button onclick="document.getElementById('status-modal-nama').textContent='{{ $a['nama'] }} — {{ $a['kode'] }}';openModal('status-modal')" style="background:#f8fafc;border:1px solid #e2e8f0;color:#64748b;padding:5px 10px;border-radius:8px;cursor:pointer;font-size:11px;font-weight:600;display:flex;align-items:center;gap:4px;" onmouseover="this.style.background='#fff7ed';this.style.color='#f97316'" onmouseout="this.style.background='#f8fafc';this.style.color='#64748b'">
                <span class="material-symbols-outlined" style="font-size:14px;">edit</span>
              </button>
              <button onclick="showToast('Aset {{ $a['kode'] }} dihapus!','delete')" style="background:#fef2f2;border:1px solid #fecaca;color:#dc2626;padding:5px 10px;border-radius:8px;cursor:pointer;font-size:11px;font-weight:600;display:flex;align-items:center;gap:4px;">
                <span class="material-symbols-outlined" style="font-size:14px;">delete</span>
              </button>
            </div>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>

    <!-- Pagination -->
    <div style="padding:14px 20px;border-top:1px solid #f1f5f9;display:flex;align-items:center;justify-content:between;gap:8px;">
      <span style="font-size:12px;color:#94a3b8;flex:1;">Menampilkan {{ count($aset) }} dari {{ count($aset) }} aset</span>
      <div style="display:flex;gap:6px;">
        @foreach(range(1,3) as $p)
        <button style="width:32px;height:32px;border-radius:8px;border:1px solid {{ $p===1?'#f97316':'#e2e8f0' }};background:{{ $p===1?'#fff7ed':'#fff' }};color:{{ $p===1?'#f97316':'#64748b' }};font-size:12px;font-weight:700;cursor:pointer;">{{ $p }}</button>
        @endforeach
        <button style="width:32px;height:32px;border-radius:8px;border:1px solid #e2e8f0;background:#fff;color:#64748b;font-size:12px;cursor:pointer;">›</button>
      </div>
    </div>
    @endif
  </div>
</div>
@endsection
