@extends('layouts.app')

@section('content')
<div style="padding:24px;display:flex;flex-direction:column;gap:16px;">
  <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:12px;">
    <div>
      <h2 style="font-family:'Sora',sans-serif;font-weight:800;font-size:20px;color:#0f172a;margin-bottom:4px;">Jadwal Pemeliharaan</h2>
      <p style="font-size:13px;color:#64748b;">Kelola jadwal servis dan pemeliharaan aset</p>
    </div>
    <button onclick="openModal('jadwal-modal')" class="btn-or">
      <span class="material-symbols-outlined" style="font-size:16px;">add</span> Tambah Jadwal
    </button>
  </div>

  <!-- Summary Cards -->
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;">
    @foreach([['Terjadwal','8','#2563eb','#eff6ff','schedule'],['Dalam Proses','2','#f59e0b','#fffbeb','pending'],['Selesai','15','#16a34a','#f0fdf4','task_alt'],['Terlewat','1','#dc2626','#fef2f2','warning']] as [$l,$n,$c,$bg,$ic])
    <div class="card-stat" style="border-left:3px solid {{ $c }};">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
        <div style="width:30px;height:30px;background:{{ $bg }};border-radius:8px;display:flex;align-items:center;justify-content:center;"><span class="material-symbols-outlined" style="color:{{ $c }};font-size:17px;">{{ $ic }}</span></div>
        <span style="font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.07em;">{{ $l }}</span>
      </div>
      <p style="font-family:'Sora',sans-serif;font-size:26px;font-weight:800;color:#0f172a;">{{ $n }}</p>
    </div>
    @endforeach
  </div>

  <!-- Jadwal List -->
  <div class="card" style="overflow:hidden;">
    <div style="padding:16px 18px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
      <h3 style="font-family:'Sora',sans-serif;font-weight:700;font-size:14px;color:#0f172a;">Jadwal April – Mei 2025</h3>
      <button onclick="showToast('Mengunduh jadwal...')" class="btn-ghost" style="font-size:12px;padding:7px 14px;"><span class="material-symbols-outlined" style="font-size:15px;">download</span> Ekspor</button>
    </div>
    <table class="tbl" style="width:100%;">
      <thead><tr>
        <th style="padding-left:20px;">Jadwal</th>
        <th>Aset</th>
        <th>Jenis Pemeliharaan</th>
        <th>Teknisi</th>
        <th>Tanggal</th>
        <th>Status</th>
        <th>Aksi</th>
      </tr></thead>
      <tbody>
        @foreach($jadwalList as $j)
        <tr>
          <td style="padding-left:20px;font-size:11px;color:#94a3b8;font-weight:700;">{{ $j['id'] }}</td>
          <td>
            <div style="font-size:13px;font-weight:700;color:#0f172a;">{{ $j['aset'] }}</div>
            <div style="font-size:11px;color:#94a3b8;">{{ $j['kantor'] }}</div>
          </td>
          <td style="font-size:12px;color:#334155;">{{ $j['jenis'] }}</td>
          <td style="font-size:12px;color:#64748b;">{{ $j['teknisi'] }}</td>
          <td>
            <div style="font-size:12px;font-weight:700;color:#0f172a;">{{ $j['tanggal'] }}</div>
            <div style="font-size:11px;color:#94a3b8;">{{ $j['waktu'] }}</div>
          </td>
          <td>
            @if($j['status'] === 'Selesai')
              <span style="background:#dcfce7;color:#166534;border:1px solid #bbf7d0;padding:2px 10px;border-radius:999px;font-size:10px;font-weight:700;">Selesai</span>
            @elseif($j['status'] === 'Dalam Proses')
              <span style="background:#fef9c3;color:#854d0e;border:1px solid #fef08a;padding:2px 10px;border-radius:999px;font-size:10px;font-weight:700;">Dalam Proses</span>
            @elseif($j['status'] === 'Terlewat')
              <span style="background:#fee2e2;color:#991b1b;border:1px solid #fecaca;padding:2px 10px;border-radius:999px;font-size:10px;font-weight:700;">Terlewat</span>
            @else
              <span style="background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe;padding:2px 10px;border-radius:999px;font-size:10px;font-weight:700;">Terjadwal</span>
            @endif
          </td>
          <td>
            <div style="display:flex;gap:6px;">
              <button onclick="showToast('Detail jadwal {{ $j['id'] }}')" style="background:#f8fafc;border:1px solid #e2e8f0;color:#64748b;padding:5px 10px;border-radius:8px;cursor:pointer;font-size:11px;font-weight:600;">Detail</button>
              @if($j['status'] === 'Terjadwal')
              <button onclick="showToast('Jadwal dimulai!')" style="background:#fff7ed;border:1px solid #fed7aa;color:#f97316;padding:5px 10px;border-radius:8px;cursor:pointer;font-size:11px;font-weight:600;">Mulai</button>
              @elseif($j['status'] === 'Dalam Proses')
              <button onclick="showToast('Jadwal ditandai selesai!')" style="background:#f0fdf4;border:1px solid #bbf7d0;color:#16a34a;padding:5px 10px;border-radius:8px;cursor:pointer;font-size:11px;font-weight:600;">Selesai</button>
              @endif
            </div>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Tambah Jadwal -->
<div class="modal" id="jadwal-modal">
  <div style="background:#fff;border-radius:20px;width:480px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,.18);">
    <div style="padding:20px 24px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
      <h3 style="font-family:'Sora',sans-serif;font-weight:800;font-size:16px;color:#0f172a;">Tambah Jadwal Pemeliharaan</h3>
      <button onclick="closeModal('jadwal-modal')" style="border:none;background:#f1f5f9;border-radius:8px;width:30px;height:30px;cursor:pointer;font-size:18px;color:#64748b;">×</button>
    </div>
    <div style="padding:20px 24px;display:flex;flex-direction:column;gap:14px;">
      <div>
        <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Aset *</label>
        <select class="field"><option>Pilih aset...</option>@foreach($asetList as $a)<option>{{ $a['kode'] }} — {{ $a['nama'] }}</option>@endforeach</select>
      </div>
      <div>
        <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Jenis Pemeliharaan *</label>
        <select class="field">
          @foreach(['Servis Rutin','Penggantian Part','Kalibrasi','Inspeksi','Pembersihan','Perbaikan Darurat'] as $j)
          <option>{{ $j }}</option>
          @endforeach
        </select>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div>
          <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Tanggal</label>
          <input type="date" class="field"/>
        </div>
        <div>
          <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Waktu</label>
          <input type="time" class="field"/>
        </div>
      </div>
      <div>
        <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Nama Teknisi</label>
        <input type="text" class="field" placeholder="Nama teknisi penanggung jawab"/>
      </div>
      <div>
        <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Catatan</label>
        <textarea class="field" placeholder="Instruksi atau catatan pemeliharaan..." style="height:70px;resize:vertical;"></textarea>
      </div>
    </div>
    <div style="padding:0 24px 20px;display:flex;gap:10px;">
      <button onclick="closeModal('jadwal-modal')" class="btn-ghost" style="flex:1;">Batal</button>
      <button onclick="closeModal('jadwal-modal');showToast('Jadwal berhasil ditambahkan!')" class="btn-or" style="flex:1;justify-content:center;">Simpan Jadwal</button>
    </div>
  </div>
</div>
@endsection
