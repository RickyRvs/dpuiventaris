@extends('layouts.app')

@section('content')
<div style="padding:24px;display:flex;flex-direction:column;gap:20px;">
  <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:12px;">
    <div>
      <h2 style="font-family:'Sora',sans-serif;font-weight:800;font-size:20px;color:#0f172a;margin-bottom:4px;">Laporan & Analitik</h2>
      <p style="font-size:13px;color:#64748b;">Ringkasan data inventaris seluruh kantor</p>
    </div>
    <div style="display:flex;gap:8px;">
      <button onclick="showToast('Mengunduh laporan PDF...')" class="btn-ghost"><span class="material-symbols-outlined" style="font-size:16px;">picture_as_pdf</span> Ekspor PDF</button>
      <button onclick="showToast('Mengunduh laporan Excel...')" class="btn-or"><span class="material-symbols-outlined" style="font-size:16px;">table_view</span> Ekspor Excel</button>
    </div>
  </div>

  <!-- Filter Periode -->
  <div class="card" style="padding:16px 20px;">
    <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
      <span style="font-size:12px;font-weight:700;color:#0f172a;">Periode:</span>
      @foreach(['Bulan Ini','3 Bulan','6 Bulan','Tahun Ini','Custom']) as $p)
      <button onclick="selectPeriode(this,'{{ $p }}')" style="padding:6px 16px;border-radius:8px;border:1.5px solid {{ $p==='Bulan Ini'?'#f97316':'#e2e8f0' }};background:{{ $p==='Bulan Ini'?'#fff7ed':'#fff' }};color:{{ $p==='Bulan Ini'?'#f97316':'#64748b' }};font-size:12px;font-weight:600;cursor:pointer;transition:all .15s;">{{ $p }}</button>
      @endforeach
      <input type="date" class="field" style="width:auto;padding:7px 12px;font-size:12px;" value="2025-04-01"/>
      <span style="font-size:12px;color:#94a3b8;">s/d</span>
      <input type="date" class="field" style="width:auto;padding:7px 12px;font-size:12px;" value="2025-04-30"/>
    </div>
  </div>

  <!-- KPI Cards -->
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px;">
    @foreach([['Total Aset Terdaftar','1.049','▲ +12 dari bulan lalu','#10b981','#f97316'],['Total Nilai Aset','Rp 3.4M','Berdasarkan nilai perolehan','#64748b','#2563eb'],['Aset Rusak','12','▼ -2 dari bulan lalu','#10b981','#dc2626'],['Tingkat Utilisasi','87%','Aset aktif digunakan','#64748b','#16a34a']] as [$l,$v,$sub,$sc,$bc])
    <div class="card-stat" style="border-left:3px solid {{ $bc }};">
      <span style="font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.07em;">{{ $l }}</span>
      <p style="font-family:'Sora',sans-serif;font-size:26px;font-weight:800;color:#0f172a;margin:8px 0 4px;">{{ $v }}</p>
      <p style="font-size:11px;font-weight:700;color:{{ $sc }};">{{ $sub }}</p>
    </div>
    @endforeach
  </div>

  <!-- Charts Row (Visual bars — no JS library needed) -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
    <!-- Kondisi per Kantor -->
    <div class="card" style="padding:20px;">
      <h3 style="font-family:'Sora',sans-serif;font-weight:700;font-size:14px;color:#0f172a;margin-bottom:18px;">Kondisi Aset per Kantor</h3>
      @foreach($kantorList as $kantor)
      @php $perbaikan = rand(1,5); $rusak = rand(1,4); $baik = $kantor['stat']['total'] - $perbaikan - $rusak; @endphp
      <div style="margin-bottom:16px;">
        <div style="display:flex;justify-content:space-between;margin-bottom:6px;">
          <span style="font-size:12px;font-weight:700;color:#0f172a;">{{ $kantor['short'] }}</span>
          <span style="font-size:11px;color:#94a3b8;">{{ $kantor['stat']['total'] }} aset</span>
        </div>
        <div style="display:flex;height:10px;border-radius:999px;overflow:hidden;gap:1px;">
          <div style="width:{{ round($baik/$kantor['stat']['total']*100) }}%;background:linear-gradient(90deg,#16a34a,#22c55e);border-radius:999px 0 0 999px;"></div>
          <div style="width:{{ round($perbaikan/$kantor['stat']['total']*100) }}%;background:linear-gradient(90deg,#ca8a04,#eab308);"></div>
          <div style="width:{{ round($rusak/$kantor['stat']['total']*100) }}%;background:linear-gradient(90deg,#dc2626,#ef4444);border-radius:0 999px 999px 0;"></div>
        </div>
        <div style="display:flex;gap:12px;margin-top:5px;">
          <span style="font-size:10px;color:#16a34a;font-weight:600;">Baik: {{ $baik }}</span>
          <span style="font-size:10px;color:#ca8a04;font-weight:600;">Perbaikan: {{ $perbaikan }}</span>
          <span style="font-size:10px;color:#dc2626;font-weight:600;">Rusak: {{ $rusak }}</span>
        </div>
      </div>
      @endforeach
    </div>

    <!-- Kategori Terbanyak -->
    <div class="card" style="padding:20px;">
      <h3 style="font-family:'Sora',sans-serif;font-weight:700;font-size:14px;color:#0f172a;margin-bottom:18px;">Distribusi Kategori</h3>
      @foreach([['Elektronik & IT',342,33],['Infrastruktur',210,20],['Furnitur Kantor',185,18],['Kendaraan',98,9],['Alat Berat',87,8],['Lainnya',127,12]] as [$k,$n,$pct])
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
        <span style="font-size:12px;color:#334155;font-weight:600;width:140px;flex-shrink:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{{ $k }}</span>
        <div class="progress-track" style="flex:1;"><div class="progress-fill" style="width:{{ $pct }}%;"></div></div>
        <span style="font-size:12px;font-weight:700;color:#0f172a;width:32px;text-align:right;">{{ $n }}</span>
      </div>
      @endforeach
    </div>
  </div>

  <!-- Tabel Laporan Detail -->
  <div class="card" style="overflow:hidden;">
    <div style="padding:16px 18px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
      <h3 style="font-family:'Sora',sans-serif;font-weight:700;font-size:14px;color:#0f172a;">Ringkasan per Kantor</h3>
    </div>
    <table class="tbl" style="width:100%;">
      <thead><tr>
        <th style="padding-left:20px;">Kantor</th>
        <th>Total Aset</th>
        <th>Baik</th>
        <th>Perbaikan</th>
        <th>Rusak</th>
        <th>Nilai Aset</th>
        <th>% Kondisi Baik</th>
      </tr></thead>
      <tbody>
        @foreach($kantorList as $kantor)
        @php $p2 = rand(1,5); $r2 = rand(1,4); $b2 = $kantor['stat']['total'] - $p2 - $r2; @endphp
        <tr>
          <td style="padding-left:20px;font-size:13px;font-weight:700;color:#0f172a;">{{ $kantor['nama'] }}</td>
          <td style="font-size:13px;font-weight:700;color:#0f172a;">{{ $kantor['stat']['total'] }}</td>
          <td style="color:#16a34a;font-weight:700;font-size:13px;">{{ $b2 }}</td>
          <td style="color:#ca8a04;font-weight:700;font-size:13px;">{{ $p2 }}</td>
          <td style="color:#dc2626;font-weight:700;font-size:13px;">{{ $r2 }}</td>
          <td style="font-size:13px;font-weight:700;color:#0f172a;">Rp {{ $kantor['stat']['nilai'] }}</td>
          <td>
            <div style="display:flex;align-items:center;gap:8px;">
              <div class="progress-track" style="width:60px;"><div class="progress-fill" style="width:{{ round($b2/$kantor['stat']['total']*100) }}%;"></div></div>
              <span style="font-size:12px;font-weight:700;color:#f97316;">{{ round($b2/$kantor['stat']['total']*100) }}%</span>
            </div>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>

@push('scripts')
<script>
function selectPeriode(btn, p) {
  document.querySelectorAll('[onclick^="selectPeriode"]').forEach(b => {
    b.style.borderColor='#e2e8f0'; b.style.background='#fff'; b.style.color='#64748b';
  });
  btn.style.borderColor='#f97316'; btn.style.background='#fff7ed'; btn.style.color='#f97316';
  showToast('Periode: ' + p);
}
</script>
@endpush
@endsection
