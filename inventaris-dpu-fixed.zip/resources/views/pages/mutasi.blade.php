@extends('layouts.app')

@section('content')
<div style="padding:24px;display:flex;flex-direction:column;gap:16px;">
  <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:12px;">
    <div>
      <h2 style="font-family:'Sora',sans-serif;font-weight:800;font-size:20px;color:#0f172a;margin-bottom:4px;">Mutasi Aset</h2>
      <p style="font-size:13px;color:#64748b;">Kelola perpindahan aset antar kantor</p>
    </div>
    <button onclick="openModal('mutasi-modal')" class="btn-or">
      <span class="material-symbols-outlined" style="font-size:16px;">add</span> Ajukan Mutasi
    </button>
  </div>

  <!-- Tab -->
  <div style="display:flex;gap:4px;background:#f1f5f9;padding:4px;border-radius:12px;width:fit-content;">
    @foreach(['Semua','Menunggu','Disetujui','Ditolak'] as $tab)
    <button onclick="filterMutasi(this,'{{ $tab }}')" style="padding:7px 16px;border-radius:9px;border:none;cursor:pointer;font-size:12px;font-weight:600;background:{{ $tab==='Semua'?'#fff':'transparent' }};color:{{ $tab==='Semua'?'#f97316':'#64748b' }};box-shadow:{{ $tab==='Semua'?'0 1px 4px rgba(0,0,0,.08)':'none' }};transition:all .15s;">{{ $tab }}</button>
    @endforeach
  </div>

  <!-- Table -->
  <div class="card" style="overflow:hidden;">
    <table class="tbl" style="width:100%;">
      <thead><tr>
        <th style="padding-left:20px;">ID Mutasi</th>
        <th>Aset</th>
        <th>Asal</th>
        <th>Tujuan</th>
        <th>Pengaju</th>
        <th>Tanggal</th>
        <th>Status</th>
        <th>Aksi</th>
      </tr></thead>
      <tbody>
        @foreach($mutasiList as $m)
        <tr>
          <td style="padding-left:20px;font-size:11px;color:#94a3b8;font-weight:700;">{{ $m['id'] }}</td>
          <td>
            <div style="font-size:13px;font-weight:700;color:#0f172a;">{{ $m['aset'] }}</div>
            <div style="font-size:11px;color:#94a3b8;">{{ $m['kode'] }}</div>
          </td>
          <td style="font-size:12px;color:#64748b;">{{ $m['asal'] }}</td>
          <td style="font-size:12px;color:#0f172a;font-weight:600;">{{ $m['tujuan'] }}</td>
          <td style="font-size:12px;color:#64748b;">{{ $m['pengaju'] }}</td>
          <td style="font-size:12px;color:#64748b;">{{ $m['tanggal'] }}</td>
          <td>
            @if($m['status'] === 'Disetujui')
              <span style="background:#dcfce7;color:#166534;border:1px solid #bbf7d0;padding:2px 10px;border-radius:999px;font-size:10px;font-weight:700;">Disetujui</span>
            @elseif($m['status'] === 'Ditolak')
              <span style="background:#fee2e2;color:#991b1b;border:1px solid #fecaca;padding:2px 10px;border-radius:999px;font-size:10px;font-weight:700;">Ditolak</span>
            @else
              <span style="background:#fef9c3;color:#854d0e;border:1px solid #fef08a;padding:2px 10px;border-radius:999px;font-size:10px;font-weight:700;">Menunggu</span>
            @endif
          </td>
          <td>
            <div style="display:flex;gap:6px;">
              @if($m['status'] === 'Menunggu' && $isAdmin)
              <button onclick="showToast('Mutasi {{ $m['id'] }} disetujui!')" style="background:#f0fdf4;border:1px solid #bbf7d0;color:#16a34a;padding:5px 10px;border-radius:8px;cursor:pointer;font-size:11px;font-weight:600;">✓ Setujui</button>
              <button onclick="showToast('Mutasi {{ $m['id'] }} ditolak!','delete')" style="background:#fef2f2;border:1px solid #fecaca;color:#dc2626;padding:5px 10px;border-radius:8px;cursor:pointer;font-size:11px;font-weight:600;">✗ Tolak</button>
              @else
              <button onclick="showToast('Detail mutasi {{ $m['id'] }}')" style="background:#f8fafc;border:1px solid #e2e8f0;color:#64748b;padding:5px 10px;border-radius:8px;cursor:pointer;font-size:11px;font-weight:600;">Detail</button>
              @endif
            </div>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Ajukan Mutasi -->
<div class="modal" id="mutasi-modal">
  <div style="background:#fff;border-radius:20px;width:500px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,.18);">
    <div style="padding:20px 24px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
      <div>
        <h3 style="font-family:'Sora',sans-serif;font-weight:800;font-size:16px;color:#0f172a;">Ajukan Mutasi Aset</h3>
        <p style="font-size:12px;color:#64748b;">Isi formulir perpindahan aset</p>
      </div>
      <button onclick="closeModal('mutasi-modal')" style="border:none;background:#f1f5f9;border-radius:8px;width:30px;height:30px;cursor:pointer;font-size:18px;color:#64748b;">×</button>
    </div>
    <div style="padding:20px 24px;display:flex;flex-direction:column;gap:14px;">
      <div>
        <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Aset yang Dimutasi *</label>
        <select class="field">
          <option>Pilih aset...</option>
          @foreach($asetList as $a)
          <option>{{ $a['kode'] }} — {{ $a['nama'] }}</option>
          @endforeach
        </select>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div>
          <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Kantor Asal</label>
          <select class="field">
            @foreach($kantorList as $k)
            <option>{{ $k['short'] }}</option>
            @endforeach
          </select>
        </div>
        <div>
          <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Kantor Tujuan *</label>
          <select class="field">
            @foreach($kantorList as $k)
            <option>{{ $k['short'] }}</option>
            @endforeach
          </select>
        </div>
      </div>
      <div>
        <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Alasan Mutasi *</label>
        <textarea class="field" placeholder="Jelaskan alasan perpindahan aset ini..." style="height:80px;resize:vertical;"></textarea>
      </div>
    </div>
    <div style="padding:0 24px 20px;display:flex;gap:10px;">
      <button onclick="closeModal('mutasi-modal')" class="btn-ghost" style="flex:1;">Batal</button>
      <button onclick="closeModal('mutasi-modal');showToast('Permintaan mutasi berhasil diajukan!')" class="btn-or" style="flex:1;justify-content:center;">Ajukan Mutasi</button>
    </div>
  </div>
</div>

@push('scripts')
<script>
function filterMutasi(btn, tab) {
  document.querySelectorAll('[onclick^="filterMutasi"]').forEach(b => {
    b.style.background = 'transparent'; b.style.color = '#64748b'; b.style.boxShadow = 'none';
  });
  btn.style.background = '#fff'; btn.style.color = '#f97316'; btn.style.boxShadow = '0 1px 4px rgba(0,0,0,.08)';
  showToast('Filter: ' + tab);
}
</script>
@endpush
@endsection
