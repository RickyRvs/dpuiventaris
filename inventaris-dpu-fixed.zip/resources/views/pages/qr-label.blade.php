@extends('layouts.app')

@section('content')
<div style="padding:24px;display:flex;flex-direction:column;gap:20px;">
  <div>
    <h2 style="font-family:'Sora',sans-serif;font-weight:800;font-size:20px;color:#0f172a;margin-bottom:4px;">QR Code & Label Aset</h2>
    <p style="font-size:13px;color:#64748b;">Generate dan cetak label QR untuk identifikasi aset</p>
  </div>

  <div style="display:grid;grid-template-columns:1fr 340px;gap:20px;">
    <!-- Daftar Aset -->
    <div class="card" style="overflow:hidden;">
      <div style="padding:14px 18px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;gap:10px;">
        <div style="position:relative;flex:1;">
          <span class="material-symbols-outlined" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:15px;">search</span>
          <input type="text" placeholder="Cari aset untuk generate QR..." class="field" style="padding-left:34px;font-size:12px;"/>
        </div>
      </div>
      <table class="tbl" style="width:100%;">
        <thead><tr>
          <th style="padding-left:20px;">Kode</th>
          <th>Nama Aset</th>
          <th>Kantor</th>
          <th>Aksi</th>
        </tr></thead>
        <tbody>
          @foreach($asetList as $a)
          <tr>
            <td style="padding-left:20px;font-size:11px;color:#94a3b8;font-weight:700;">{{ $a['kode'] }}</td>
            <td>
              <div style="font-size:13px;font-weight:700;color:#0f172a;">{{ $a['nama'] }}</div>
              <div style="font-size:11px;color:#94a3b8;">{{ $a['kategori'] }}</div>
            </td>
            <td style="font-size:12px;color:#64748b;">{{ $a['kantor'] }}</td>
            <td>
              <button onclick="selectQrAset('{{ $a['kode'] }}','{{ $a['nama'] }}','{{ $a['kantor'] }}','{{ $a['ruangan'] }}')" style="background:#fff7ed;border:1px solid #fed7aa;color:#f97316;padding:5px 12px;border-radius:8px;cursor:pointer;font-size:11px;font-weight:600;display:flex;align-items:center;gap:4px;">
                <span class="material-symbols-outlined" style="font-size:13px;">qr_code</span> Generate
              </button>
            </td>
          </tr>
          @endforeach
        </tbody>
      </table>
    </div>

    <!-- QR Preview Panel -->
    <div style="display:flex;flex-direction:column;gap:14px;">
      <div class="card" style="padding:20px;text-align:center;" id="qr-panel">
        <p style="font-size:12px;color:#94a3b8;font-weight:600;margin-bottom:16px;">Pilih aset untuk preview QR</p>
        <!-- QR Placeholder -->
        <div style="width:150px;height:150px;border:2px solid #e2e8f0;border-radius:12px;margin:0 auto 16px;display:flex;align-items:center;justify-content:center;background:#f8fafc;">
          <span class="material-symbols-outlined" style="font-size:64px;color:#e2e8f0;">qr_code_2</span>
        </div>
        <p id="qr-nama" style="font-size:13px;font-weight:700;color:#0f172a;margin-bottom:2px;">—</p>
        <p id="qr-kode" style="font-size:11px;color:#94a3b8;margin-bottom:16px;">—</p>
        <div style="display:flex;gap:8px;">
          <button onclick="showToast('Label QR dicetak!')" class="btn-or" style="flex:1;font-size:12px;padding:9px;justify-content:center;"><span class="material-symbols-outlined" style="font-size:15px;">print</span> Cetak</button>
          <button onclick="showToast('QR label diunduh!')" class="btn-ghost" style="flex:1;font-size:12px;padding:9px;justify-content:center;"><span class="material-symbols-outlined" style="font-size:15px;">download</span> Unduh</button>
        </div>
      </div>

      <!-- Bulk Print -->
      <div class="card" style="padding:18px;">
        <h3 style="font-family:'Sora',sans-serif;font-weight:700;font-size:13px;color:#0f172a;margin-bottom:12px;">Cetak Massal</h3>
        <div style="display:flex;flex-direction:column;gap:8px;">
          @foreach([['Semua aset Pekanbaru','42 aset'],['Semua aset Jakarta','28 aset'],['Aset Elektronik','35 aset'],['Aset Rusak / Perbaikan','7 aset']] as [$label,$count])
          <div style="display:flex;align-items:center;justify-content:space-between;padding:9px 12px;background:#f8fafc;border-radius:9px;border:1px solid #f1f5f9;">
            <div>
              <p style="font-size:12px;font-weight:700;color:#0f172a;">{{ $label }}</p>
              <p style="font-size:10px;color:#94a3b8;">{{ $count }}</p>
            </div>
            <button onclick="showToast('Mencetak {{ $count }}...')" style="background:#fff7ed;border:1px solid #fed7aa;color:#f97316;padding:4px 10px;border-radius:7px;cursor:pointer;font-size:11px;font-weight:700;">Cetak</button>
          </div>
          @endforeach
        </div>
      </div>
    </div>
  </div>
</div>

@push('scripts')
<script>
function selectQrAset(kode, nama, kantor, ruangan) {
  document.getElementById('qr-nama').textContent = nama;
  document.getElementById('qr-kode').textContent = kode + ' · ' + kantor;
  // Generate fake QR grid visual
  const panel = document.getElementById('qr-panel');
  const qrBox = panel.querySelector('div[style*="150px"]');
  let cells = '';
  for(let i=0;i<49;i++) {
    const on = Math.random() > 0.45;
    cells += `<div style="background:${on?'#0f172a':'transparent'};border-radius:1px;"></div>`;
  }
  qrBox.innerHTML = `<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:2px;padding:12px;width:100%;height:100%;">${cells}</div>`;
  showToast('QR ' + kode + ' berhasil digenerate!');
}
</script>
@endpush
@endsection
