@extends('layouts.app')

@section('content')
<div style="padding:24px;display:flex;flex-direction:column;gap:16px;">
  <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:12px;">
    <div>
      <h2 style="font-family:'Sora',sans-serif;font-weight:800;font-size:20px;color:#0f172a;margin-bottom:4px;">Manajemen Stok</h2>
      <p style="font-size:13px;color:#64748b;">Pantau ketersediaan bahan & suku cadang</p>
    </div>
    <div style="display:flex;gap:8px;">
      <button onclick="openModal('pengadaan-modal')" class="btn-ghost"><span class="material-symbols-outlined" style="font-size:16px;">shopping_cart</span> Permintaan Pengadaan</button>
      <button onclick="openModal('stok-modal')" class="btn-or"><span class="material-symbols-outlined" style="font-size:16px;">add</span> Tambah Item</button>
    </div>
  </div>

  <!-- Stats -->
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:12px;">
    @foreach([['Total Item','18','#f97316','#fff7ed','shelves'],['Stok Aman','14','#16a34a','#f0fdf4','inventory'],['Stok Kritis','3','#dc2626','#fef2f2','warning'],['Habis','1','#94a3b8','#f8fafc','remove_circle']] as [$l,$n,$c,$bg,$ic])
    <div class="card-stat" style="border-left:3px solid {{ $c }};">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
        <span style="font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.07em;">{{ $l }}</span>
        <div style="width:30px;height:30px;background:{{ $bg }};border-radius:8px;display:flex;align-items:center;justify-content:center;"><span class="material-symbols-outlined" style="color:{{ $c }};font-size:17px;">{{ $ic }}</span></div>
      </div>
      <p style="font-family:'Sora',sans-serif;font-size:26px;font-weight:800;color:#0f172a;">{{ $n }}</p>
    </div>
    @endforeach
  </div>

  <!-- Stok Kritis Alert -->
  <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:14px;padding:14px 18px;display:flex;align-items:flex-start;gap:12px;">
    <span class="material-symbols-outlined fill-icon" style="color:#ef4444;font-size:22px;margin-top:1px;">warning</span>
    <div style="flex:1;">
      <p style="font-size:13px;font-weight:700;color:#991b1b;margin-bottom:4px;">⚠ Perhatian: 3 item stok di bawah minimum</p>
      <p style="font-size:12px;color:#dc2626;">Toner Printer HP (2/5), Sabuk Pengaman (8/10), Baterai Total Station (2/2 — habis)</p>
    </div>
    <button onclick="openModal('pengadaan-modal')" style="background:#dc2626;color:#fff;border:none;border-radius:8px;padding:6px 14px;font-size:12px;font-weight:700;cursor:pointer;flex-shrink:0;">Buat Pengadaan</button>
  </div>

  <!-- Table -->
  <div class="card" style="overflow:hidden;">
    <div style="padding:14px 18px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;gap:10px;">
      <div style="position:relative;flex:1;max-width:280px;">
        <span class="material-symbols-outlined" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:15px;">search</span>
        <input type="text" placeholder="Cari item stok..." class="field" style="padding-left:34px;font-size:12px;"/>
      </div>
      <select class="field" style="width:auto;padding:8px 12px;font-size:12px;">
        <option>Semua Kategori</option>
        @foreach(['Konsumabel','Suku Cadang','Mekanikal','Bahan Bakar','K3','Perawatan'] as $k)
        <option>{{ $k }}</option>
        @endforeach
      </select>
    </div>
    <table class="tbl" style="width:100%;">
      <thead><tr>
        <th style="padding-left:20px;">Kode</th>
        <th>Nama Item</th>
        <th>Kategori</th>
        <th>Kantor</th>
        <th>Stok Saat Ini</th>
        <th>Min. Stok</th>
        <th>Status</th>
        <th>Aksi</th>
      </tr></thead>
      <tbody>
        @foreach($stokList as $s)
        <tr>
          <td style="padding-left:20px;font-size:11px;color:#94a3b8;font-weight:700;">{{ $s['kode'] }}</td>
          <td style="font-size:13px;font-weight:700;color:#0f172a;">{{ $s['nama'] }}</td>
          <td style="font-size:12px;color:#64748b;">{{ $s['kategori'] }}</td>
          <td style="font-size:12px;color:#64748b;">{{ $s['kantor'] }}</td>
          <td>
            <div style="display:flex;align-items:center;gap:8px;">
              <div class="progress-track" style="width:70px;"><div class="progress-fill" style="width:{{ min(100, round($s['stok']/$s['min']*100)) }}%;background:{{ $s['stok'] < $s['min'] ? 'linear-gradient(90deg,#dc2626,#ef4444)' : 'linear-gradient(90deg,#16a34a,#22c55e)' }};"></div></div>
              <span style="font-size:13px;font-weight:700;color:#0f172a;">{{ $s['stok'] }} {{ $s['satuan'] }}</span>
            </div>
          </td>
          <td style="font-size:12px;color:#94a3b8;">{{ $s['min'] }} {{ $s['satuan'] }}</td>
          <td>
            @if($s['stok'] == 0)
              <span style="background:#f1f5f9;color:#64748b;border:1px solid #e2e8f0;padding:2px 10px;border-radius:999px;font-size:10px;font-weight:700;">Habis</span>
            @elseif($s['stok'] < $s['min'])
              <span class="badge-rusak">Kritis</span>
            @else
              <span class="badge-baik">Aman</span>
            @endif
          </td>
          <td>
            <div style="display:flex;gap:6px;">
              <button onclick="showToast('Stok {{ $s['nama'] }} diperbarui!')" style="background:#fff7ed;border:1px solid #fed7aa;color:#f97316;padding:5px 10px;border-radius:8px;cursor:pointer;font-size:11px;font-weight:600;display:flex;align-items:center;gap:4px;"><span class="material-symbols-outlined" style="font-size:13px;">edit</span> Update</button>
              <button onclick="showToast('Riwayat stok {{ $s['kode'] }}')" style="background:#f8fafc;border:1px solid #e2e8f0;color:#64748b;padding:5px 10px;border-radius:8px;cursor:pointer;font-size:11px;font-weight:600;display:flex;align-items:center;gap:4px;"><span class="material-symbols-outlined" style="font-size:13px;">history</span></button>
            </div>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Tambah Item Stok -->
<div class="modal" id="stok-modal">
  <div style="background:#fff;border-radius:20px;width:460px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,.18);">
    <div style="padding:20px 24px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
      <h3 style="font-family:'Sora',sans-serif;font-weight:800;font-size:16px;color:#0f172a;">Tambah Item Stok</h3>
      <button onclick="closeModal('stok-modal')" style="border:none;background:#f1f5f9;border-radius:8px;width:30px;height:30px;cursor:pointer;font-size:18px;color:#64748b;">×</button>
    </div>
    <div style="padding:20px 24px;display:flex;flex-direction:column;gap:14px;">
      <div><label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Nama Item *</label><input type="text" class="field" placeholder="Contoh: Toner Printer HP LaserJet"/></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div><label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Kategori *</label>
          <select class="field">@foreach(['Konsumabel','Suku Cadang','Mekanikal','Bahan Bakar','K3','Perawatan'] as $k)<option>{{ $k }}</option>@endforeach</select>
        </div>
        <div><label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Satuan</label><input type="text" class="field" placeholder="unit / rim / liter..."/></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div><label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Stok Awal</label><input type="number" class="field" placeholder="0" min="0"/></div>
        <div><label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Minimum Stok</label><input type="number" class="field" placeholder="5" min="0"/></div>
      </div>
      <div><label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Kantor</label>
        <select class="field">@foreach($kantorList as $k)<option>{{ $k['short'] }}</option>@endforeach</select>
      </div>
    </div>
    <div style="padding:0 24px 20px;display:flex;gap:10px;">
      <button onclick="closeModal('stok-modal')" class="btn-ghost" style="flex:1;">Batal</button>
      <button onclick="closeModal('stok-modal');showToast('Item stok berhasil ditambahkan!')" class="btn-or" style="flex:1;justify-content:center;">Simpan</button>
    </div>
  </div>
</div>

<!-- Modal Permintaan Pengadaan -->
<div class="modal" id="pengadaan-modal">
  <div style="background:#fff;border-radius:20px;width:460px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,.18);">
    <div style="padding:20px 24px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
      <h3 style="font-family:'Sora',sans-serif;font-weight:800;font-size:16px;color:#0f172a;">Permintaan Pengadaan</h3>
      <button onclick="closeModal('pengadaan-modal')" style="border:none;background:#f1f5f9;border-radius:8px;width:30px;height:30px;cursor:pointer;font-size:18px;color:#64748b;">×</button>
    </div>
    <div style="padding:20px 24px;display:flex;flex-direction:column;gap:14px;">
      <div><label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Item yang Dipesan *</label>
        <select class="field"><option>Pilih item...</option>@foreach($stokList as $s)<option>{{ $s['kode'] }} — {{ $s['nama'] }}</option>@endforeach</select>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div><label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Jumlah *</label><input type="number" class="field" placeholder="10" min="1"/></div>
        <div><label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Prioritas</label>
          <select class="field"><option>Normal</option><option>Mendesak</option><option>Kritis</option></select>
        </div>
      </div>
      <div><label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Alasan Pengadaan</label><textarea class="field" placeholder="Jelaskan kebutuhan pengadaan ini..." style="height:70px;resize:vertical;"></textarea></div>
    </div>
    <div style="padding:0 24px 20px;display:flex;gap:10px;">
      <button onclick="closeModal('pengadaan-modal')" class="btn-ghost" style="flex:1;">Batal</button>
      <button onclick="closeModal('pengadaan-modal');showToast('Permintaan pengadaan berhasil dibuat!')" class="btn-or" style="flex:1;justify-content:center;">Kirim Permintaan</button>
    </div>
  </div>
</div>
@endsection
