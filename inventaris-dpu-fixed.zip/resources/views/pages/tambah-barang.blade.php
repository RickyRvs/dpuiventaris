@extends('layouts.app')

@section('content')
<div style="padding:24px;max-width:860px;">
  <!-- Header -->
  <div style="display:flex;align-items:center;gap:12px;margin-bottom:22px;">
    <a href="{{ route('inventaris') }}" style="width:34px;height:34px;border-radius:10px;background:#f8fafc;border:1px solid #e2e8f0;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#64748b;text-decoration:none;" onmouseover="this.style.background='#fff7ed'" onmouseout="this.style.background='#f8fafc'">
      <span class="material-symbols-outlined" style="font-size:18px;">arrow_back</span>
    </a>
    <div>
      <h2 style="font-family:'Sora',sans-serif;font-weight:800;font-size:20px;color:#0f172a;margin-bottom:2px;">Tambah / Edit Aset</h2>
      <p style="font-size:12px;color:#94a3b8;">Isi formulir di bawah untuk mendaftarkan aset baru</p>
    </div>
  </div>

  <form method="POST" action="#" onsubmit="event.preventDefault();showToast('Aset berhasil disimpan!')">
    @csrf
    <div class="card" style="padding:28px;display:flex;flex-direction:column;gap:24px;">

      <!-- Informasi Dasar -->
      <section>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
          <span class="material-symbols-outlined" style="color:#f97316;">info</span>
          <span style="font-size:11px;font-weight:700;color:#0f172a;text-transform:uppercase;letter-spacing:.08em;">Informasi Dasar</span>
          <div style="flex:1;height:1px;background:#f1f5f9;"></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
          <div style="grid-column:1/-1;">
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Nama Barang *</label>
            <input type="text" name="nama" placeholder="Contoh: Workstation Dell Precision 3660" class="field"/>
          </div>
          <div>
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Kategori *</label>
            <select name="kategori" class="field">
              @foreach(['Elektronik & IT','Furnitur Kantor','Peralatan Survey','Kendaraan','Alat Berat','Infrastruktur','Mekanikal & Elektrikal','Peralatan Konstruksi','Konsumabel'] as $kat)
              <option>{{ $kat }}</option>
              @endforeach
            </select>
          </div>
          <div>
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Nomor Seri / SKU</label>
            <input type="text" name="sn" placeholder="SN-XXXXXX" class="field"/>
          </div>
          <div>
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Merek / Pabrikan</label>
            <input type="text" name="merek" placeholder="Contoh: Dell, Daikin, Toyota" class="field"/>
          </div>
          <div>
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Model / Tipe</label>
            <input type="text" name="model" placeholder="Contoh: Precision 3660 Tower" class="field"/>
          </div>
        </div>
      </section>

      <!-- Lokasi & PJ -->
      <section>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
          <span class="material-symbols-outlined" style="color:#f97316;">location_on</span>
          <span style="font-size:11px;font-weight:700;color:#0f172a;text-transform:uppercase;letter-spacing:.08em;">Lokasi & Penanggung Jawab</span>
          <div style="flex:1;height:1px;background:#f1f5f9;"></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;">
          <div>
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Kantor *</label>
            <select name="kantor" class="field" {{ !$isAdmin ? 'disabled' : '' }}>
              @foreach($kantorList as $id => $kantor)
              <option value="{{ $id }}">{{ $kantor['nama'] }}</option>
              @endforeach
            </select>
          </div>
          <div>
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Ruangan / Lokasi</label>
            <input type="text" name="ruangan" placeholder="Lt. 2 - Studio Desain" class="field"/>
          </div>
          <div>
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Penanggung Jawab *</label>
            <input type="text" name="pj" placeholder="Nama penanggung jawab" class="field"/>
          </div>
        </div>
      </section>

      <!-- Nilai & Kondisi -->
      <section>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
          <span class="material-symbols-outlined" style="color:#f97316;">payments</span>
          <span style="font-size:11px;font-weight:700;color:#0f172a;text-transform:uppercase;letter-spacing:.08em;">Data Pengadaan & Kondisi</span>
          <div style="flex:1;height:1px;background:#f1f5f9;"></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;">
          <div>
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Nilai Perolehan (Rp)</label>
            <input type="text" name="nilai" placeholder="0" class="field" oninput="this.value=this.value.replace(/\D/g,'').replace(/\B(?=(\d{3})+(?!\d))/g,'.')"/>
          </div>
          <div>
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Tanggal Pengadaan</label>
            <input type="date" name="tanggal" class="field"/>
          </div>
          <div>
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Kondisi Awal *</label>
            <select name="kondisi" class="field">
              <option>Baik</option>
              <option>Dalam Perbaikan</option>
              <option>Rusak</option>
            </select>
          </div>
          <div>
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Garansi (Bulan)</label>
            <input type="number" name="garansi" placeholder="12" class="field" min="0"/>
          </div>
          <div>
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Tanggal Garansi Habis</label>
            <input type="date" name="garansi_habis" class="field"/>
          </div>
          <div>
            <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;">Kode Aset (Auto)</label>
            <input type="text" value="DPU-{{ rand(6000,9999) }}" class="field" readonly style="background:#f1f5f9;color:#64748b;"/>
          </div>
        </div>
      </section>

      <!-- Catatan -->
      <section>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
          <span class="material-symbols-outlined" style="color:#f97316;">notes</span>
          <span style="font-size:11px;font-weight:700;color:#0f172a;text-transform:uppercase;letter-spacing:.08em;">Catatan Tambahan</span>
          <div style="flex:1;height:1px;background:#f1f5f9;"></div>
        </div>
        <textarea name="catatan" placeholder="Tambahkan catatan kondisi, spesifikasi khusus, atau informasi lainnya..." class="field" style="height:90px;resize:vertical;"></textarea>
      </section>

      <!-- Upload Foto -->
      <section>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
          <span class="material-symbols-outlined" style="color:#f97316;">photo_camera</span>
          <span style="font-size:11px;font-weight:700;color:#0f172a;text-transform:uppercase;letter-spacing:.08em;">Foto Aset</span>
          <div style="flex:1;height:1px;background:#f1f5f9;"></div>
        </div>
        <div style="border:2px dashed #e2e8f0;border-radius:12px;padding:28px;text-align:center;cursor:pointer;transition:all .15s;" onmouseover="this.style.borderColor='#f97316';this.style.background='#fff7ed'" onmouseout="this.style.borderColor='#e2e8f0';this.style.background='transparent'" onclick="showToast('Pilih foto dari komputer Anda')">
          <span class="material-symbols-outlined" style="font-size:36px;color:#cbd5e1;display:block;margin-bottom:8px;">cloud_upload</span>
          <p style="font-size:13px;color:#64748b;font-weight:600;">Klik untuk upload foto</p>
          <p style="font-size:11px;color:#94a3b8;margin-top:4px;">PNG, JPG hingga 10MB</p>
        </div>
      </section>

      <!-- Action Buttons -->
      <div style="display:flex;gap:12px;justify-content:flex-end;padding-top:8px;border-top:1px solid #f1f5f9;">
        <a href="{{ route('inventaris') }}" class="btn-ghost">Batal</a>
        <button type="submit" class="btn-or">
          <span class="material-symbols-outlined" style="font-size:17px;">save</span> Simpan Aset
        </button>
      </div>
    </div>
  </form>
</div>
@endsection
