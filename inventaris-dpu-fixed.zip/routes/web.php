<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InventarisController;

Route::get('/', fn() => redirect()->route('login'));

Route::get('/login', [InventarisController::class, 'loginForm'])->name('login');
Route::post('/login', [InventarisController::class, 'loginPost'])->name('login.post');
Route::post('/logout', [InventarisController::class, 'logout'])->name('logout');

Route::middleware([\App\Http\Middleware\AuthMiddleware::class])->group(function () {
    Route::get('/dashboard', [InventarisController::class, 'dashboard'])->name('dashboard');
    Route::get('/inventaris', [InventarisController::class, 'inventaris'])->name('inventaris');
    Route::get('/tambah-barang', [InventarisController::class, 'tambahBarang'])->name('tambah-barang');
    Route::get('/mutasi', [InventarisController::class, 'mutasi'])->name('mutasi');
    Route::get('/jadwal', [InventarisController::class, 'jadwal'])->name('jadwal');
    Route::get('/stok', [InventarisController::class, 'stok'])->name('stok');
    Route::get('/qr-label', [InventarisController::class, 'qrLabel'])->name('qr-label');
    Route::get('/laporan', [InventarisController::class, 'laporan'])->name('laporan');
    Route::get('/pengaturan', [InventarisController::class, 'pengaturan'])->name('pengaturan');
    Route::get('/manajemen-user', [InventarisController::class, 'manajemenUser'])->name('manajemen-user');
    Route::get('/audit-log', [InventarisController::class, 'auditLog'])->name('audit-log');
});
